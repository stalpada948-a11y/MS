package com.example.data

import android.content.Context
import android.content.SharedPreferences

class XoPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("xo_ai_preferences", Context.MODE_PRIVATE)

    var apiKey: String
        get() = prefs.getString(KEY_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_API_KEY, value).apply()

    var wakeWordEnabled: Boolean
        get() = prefs.getBoolean(KEY_WAKE_WORD_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_WAKE_WORD_ENABLED, value).apply()

    var wakePhrase: String
        get() = prefs.getString(KEY_WAKE_PHRASE, "Hey XO") ?: "Hey XO"
        set(value) = prefs.edit().putString(KEY_WAKE_PHRASE, value).apply()

    var voicePitch: Float
        get() = prefs.getFloat(KEY_VOICE_PITCH, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_VOICE_PITCH, value).apply()

    var voiceSpeed: Float
        get() = prefs.getFloat(KEY_VOICE_SPEED, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_VOICE_SPEED, value).apply()

    var isDarkMode: Boolean
        get() = prefs.getBoolean(KEY_DARK_MODE, true)
        set(value) = prefs.edit().putBoolean(KEY_DARK_MODE, value).apply()

    var isOnboardingCompleted: Boolean
        get() = prefs.getBoolean(KEY_ONBOARDING_COMPLETED, false)
        set(value) = prefs.edit().putBoolean(KEY_ONBOARDING_COMPLETED, value).apply()

    var isOverlayEnabled: Boolean
        get() = prefs.getBoolean(KEY_OVERLAY_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_OVERLAY_ENABLED, value).apply()

    var elevenLabsApiKey: String
        get() = prefs.getString(KEY_ELEVENLABS_API_KEY, "") ?: ""
        set(value) = prefs.edit().putString(KEY_ELEVENLABS_API_KEY, value).apply()

    var elevenLabsVoiceId: String
        get() = prefs.getString(KEY_ELEVENLABS_VOICE_ID, "21m00Tcm4TlvDq8ikWAM") ?: "21m00Tcm4TlvDq8ikWAM"
        set(value) = prefs.edit().putString(KEY_ELEVENLABS_VOICE_ID, value).apply()

    var useElevenLabsTts: Boolean
        get() = prefs.getBoolean(KEY_USE_ELEVENLABS_TTS, true)
        set(value) = prefs.edit().putBoolean(KEY_USE_ELEVENLABS_TTS, value).apply()

    var isGestureTrackingEnabled: Boolean
        get() = prefs.getBoolean(KEY_GESTURE_TRACKING_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_GESTURE_TRACKING_ENABLED, value).apply()

    companion object {
        private const val KEY_API_KEY = "key_api_key"
        private const val KEY_WAKE_WORD_ENABLED = "key_wake_word_enabled"
        private const val KEY_WAKE_PHRASE = "key_wake_phrase"
        private const val KEY_VOICE_PITCH = "key_voice_pitch"
        private const val KEY_VOICE_SPEED = "key_voice_speed"
        private const val KEY_DARK_MODE = "key_dark_mode"
        private const val KEY_ONBOARDING_COMPLETED = "key_onboarding_completed"
        private const val KEY_OVERLAY_ENABLED = "key_overlay_enabled"
        private const val KEY_ELEVENLABS_API_KEY = "key_elevenlabs_api_key"
        private const val KEY_ELEVENLABS_VOICE_ID = "key_elevenlabs_voice_id"
        private const val KEY_USE_ELEVENLABS_TTS = "key_use_elevenlabs_tts"
        private const val KEY_GESTURE_TRACKING_ENABLED = "key_gesture_tracking_enabled"
    }
}
