package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonPurple = Color(0xFFA855F7)
val NeonViolet = Color(0xFFC084FC)
val NeonPurpleGlow = Color(0x66A855F7)
val ElectricMagenta = Color(0xFFE879F9)

val NeonGreen = Color(0xFF00FF66)
val NeonGreenDark = Color(0xFF00CC52)
val NeonGreenGlow = Color(0x3300FF66)

val CyberCyan = Color(0xFF00E5FF)
val CyberPink = Color(0xFFFF0055)

val DeepObsidian = Color(0xFF0B0813)
val PureBlack = Color(0xFF000000)
val DarkSurface = Color(0xFF110B1F)
val DarkGlass = Color(0xFF181029)
val DarkGlassBorder = Color(0xFF38235C)
val DarkCard = Color(0xFF22163B)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFBCA6E6)
val TextMuted = Color(0xFF7D65A8)
