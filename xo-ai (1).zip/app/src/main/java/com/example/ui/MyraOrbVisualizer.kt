package com.example.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricMagenta
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonPurpleGlow
import com.example.ui.theme.NeonViolet
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MyraOrbVisualizer(
    isSpeaking: Boolean,
    isListening: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 240.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "MyraOrbTransition")

    // Slow ambient rotation for outer particles
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Pulsing pulse animation when speaking
    val speakPulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.35f,
        animationSpec = infiniteRepeatable(
            animation = tween(450, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "speakPulse"
    )

    // Breathing pulse scale when listening or idle
    val breatheScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.10f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathe"
    )

    val currentScale = if (isSpeaking) speakPulseScale else if (isListening) breatheScale else breatheScale

    val orbCoreColors = when {
        isSpeaking -> listOf(ElectricMagenta, NeonPurple, NeonViolet, Color.Transparent)
        isListening -> listOf(CyberCyan, NeonPurple, NeonViolet, Color.Transparent)
        else -> listOf(NeonPurple, NeonViolet, Color(0x22A855F7), Color.Transparent)
    }

    val interactionSource = remember { MutableInteractionSource() }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = this.center
            val baseRadius = size.toPx() / 2f

            // 1. Draw Outer Glow Aura
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        orbCoreColors[0].copy(alpha = if (isSpeaking) 0.6f else 0.35f),
                        orbCoreColors[1].copy(alpha = 0.2f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = baseRadius * currentScale * 1.25f
                ),
                radius = baseRadius * currentScale * 1.25f,
                center = center
            )

            // 2. Draw Concentric 3D Rotating Orbital Rings
            rotate(rotationAngle, center) {
                // Ring 1 (Outer Purple Particle Ring)
                drawCircle(
                    color = NeonViolet.copy(alpha = 0.4f),
                    radius = baseRadius * 0.85f * currentScale,
                    center = center,
                    style = Stroke(
                        width = 3f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 25f), 0f)
                    )
                )

                // Particle Dots on Ring 1
                val particleCount = 12
                for (i in 0 until particleCount) {
                    val angle = (i * 360f / particleCount) * (Math.PI / 180.0)
                    val r = baseRadius * 0.85f * currentScale
                    val x = center.x + (r * cos(angle)).toFloat()
                    val y = center.y + (r * sin(angle)).toFloat()
                    drawCircle(
                        color = if (i % 2 == 0) ElectricMagenta else NeonPurple,
                        radius = if (isSpeaking) 6f else 4f,
                        center = androidx.compose.ui.geometry.Offset(x, y)
                    )
                }
            }

            rotate(-rotationAngle * 1.5f, center) {
                // Ring 2 (Inner Cyan / Violet Particle Ring)
                drawCircle(
                    color = if (isListening) CyberCyan.copy(alpha = 0.6f) else NeonPurpleGlow,
                    radius = baseRadius * 0.65f * currentScale,
                    center = center,
                    style = Stroke(
                        width = 4f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(20f, 15f), 0f)
                    )
                )

                // Particle Dots on Ring 2
                val innerParticles = 8
                for (i in 0 until innerParticles) {
                    val angle = (i * 360f / innerParticles) * (Math.PI / 180.0)
                    val r = baseRadius * 0.65f * currentScale
                    val x = center.x + (r * cos(angle)).toFloat()
                    val y = center.y + (r * sin(angle)).toFloat()
                    drawCircle(
                        color = if (isListening) CyberCyan else NeonViolet,
                        radius = 5f,
                        center = androidx.compose.ui.geometry.Offset(x, y)
                    )
                }
            }

            // 3. Central 3D Glowing Orb Core
            scale(currentScale, center) {
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = orbCoreColors,
                        center = center,
                        radius = baseRadius * 0.5f
                    ),
                    radius = baseRadius * 0.5f,
                    center = center
                )

                // High-Intensity Center Core Pulse
                drawCircle(
                    color = Color.White.copy(alpha = if (isSpeaking) 0.85f else 0.5f),
                    radius = baseRadius * 0.18f * (if (isSpeaking) 1.2f else 1.0f),
                    center = center
                )
            }
        }
    }
}
