package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.AiResponse
import com.example.ai.GeminiManager
import com.example.data.db.ChatMessageDao
import com.example.data.db.ChatMessageEntity
import com.example.services.SpeechManager
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkGlass
import com.example.ui.theme.DarkGlassBorder
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.PureBlack
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatTab(
    chatMessageDao: ChatMessageDao,
    geminiManager: GeminiManager,
    speechManager: SpeechManager
) {
    val messages by chatMessageDao.getAllMessages().collectAsState(initial = emptyList())
    val isListening by speechManager.isListening.collectAsState()
    val isSpeaking by speechManager.isSpeaking.collectAsState()
    val recognizedSpeechText by speechManager.speechText.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var isProcessing by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    // Sync speech text input
    LaunchedEffect(recognizedSpeechText) {
        if (recognizedSpeechText.isNotBlank()) {
            inputText = recognizedSpeechText
        }
    }

    // Auto scroll to bottom
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val quickPrompts = listOf(
        "Scan local network",
        "Check network status",
        "Run port diagnostic",
        "Open Settings",
        "Set volume to 80%"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(horizontal = 16.dp)
            .testTag("chat_tab_screen")
    ) {
        // Top Status Pill Bar Widget
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(modifier = Modifier.weight(1f)) {
                FloatingOverlayView(
                    speechManager = speechManager,
                    onTap = {
                        if (isListening) {
                            speechManager.stopListening()
                        } else {
                            speechManager.startListening { recognized ->
                                inputText = recognized
                            }
                        }
                    },
                    onExpandChat = {
                        // Double tap action
                    }
                )
            }

            IconButton(
                onClick = {
                    coroutineScope.launch {
                        chatMessageDao.clearHistory()
                    }
                },
                modifier = Modifier.testTag("clear_chat_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Clear History",
                    tint = Color.Gray
                )
            }
        }

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    EmptyChatCard(
                        isSpeaking = isSpeaking,
                        isListening = isListening,
                        onOrbClick = {
                            if (isListening) {
                                speechManager.stopListening()
                            } else {
                                speechManager.startListening { recognized ->
                                    inputText = recognized
                                }
                            }
                        }
                    )
                }
            } else {
                items(messages) { msg ->
                    ChatMessageItem(
                        message = msg,
                        onSpeak = { speechManager.speak(msg.text) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Input & Voice Action Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    if (isListening) {
                        speechManager.stopListening()
                    } else {
                        speechManager.startListening { recognized ->
                            inputText = recognized
                        }
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (isListening) NeonPurple else DarkGlass)
                    .border(1.dp, NeonPurple, CircleShape)
                    .testTag("voice_mic_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Voice Input",
                    tint = if (isListening) PureBlack else NeonPurple
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Ask XO AI or state command...", color = Color.Gray) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonPurple,
                    unfocusedBorderColor = DarkGlassBorder,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_field")
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (inputText.isNotBlank() && !isProcessing) {
                        val userPrompt = inputText.trim()
                        inputText = ""
                        isProcessing = true

                        coroutineScope.launch {
                            // Insert user message
                            chatMessageDao.insertMessage(
                                ChatMessageEntity(sender = "user", text = userPrompt)
                            )

                            // Process AI Response
                            val aiRes = geminiManager.processUserPrompt(userPrompt)
                            isProcessing = false

                            when (aiRes) {
                                is AiResponse.TextResponse -> {
                                    chatMessageDao.insertMessage(
                                        ChatMessageEntity(sender = "xo", text = aiRes.text, actionExecuted = aiRes.actionExecuted)
                                    )
                                    speechManager.speak(aiRes.text)
                                }
                                is AiResponse.ActionResponse -> {
                                    chatMessageDao.insertMessage(
                                        ChatMessageEntity(sender = "xo", text = aiRes.text, actionExecuted = aiRes.actionName)
                                    )
                                    speechManager.speak(aiRes.text)
                                }
                                is AiResponse.ErrorResponse -> {
                                    chatMessageDao.insertMessage(
                                        ChatMessageEntity(sender = "xo", text = aiRes.error)
                                    )
                                }
                            }
                        }
                    }
                },
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(NeonPurple)
                    .testTag("send_message_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "Send",
                    tint = PureBlack
                )
            }
        }
    }
}

@Composable
private fun ChatMessageItem(
    message: ChatMessageEntity,
    onSpeak: () -> Unit
) {
    val isUser = message.sender == "user"
    val timeStr = remember(message.timestamp) {
        SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(message.timestamp))
    }

    Column(
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
        modifier = Modifier.fillMaxWidth()
    ) {
        Card(
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) Color(0xFF142B20) else DarkGlass
            ),
            border = androidx.compose.foundation.BorderStroke(
                1.dp,
                if (isUser) NeonGreen.copy(alpha = 0.6f) else DarkGlassBorder
            ),
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            modifier = Modifier.fillMaxWidth(0.85f)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (isUser) "You" else "XO AI",
                        color = if (isUser) NeonGreen else CyberCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    if (!isUser) {
                        IconButton(
                            onClick = onSpeak,
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Read Aloud",
                                tint = NeonGreen,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = message.text,
                    color = Color.White,
                    fontSize = 14.sp
                )

                if (!message.actionExecuted.isNullOrEmpty()) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF1B3D2B))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "⚡ Executed: ${message.actionExecuted}",
                            color = NeonGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = timeStr,
                    color = Color.Gray,
                    fontSize = 10.sp,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

@Composable
private fun EmptyChatCard(
    isSpeaking: Boolean = false,
    isListening: Boolean = false,
    onOrbClick: () -> Unit = {}
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp)
    ) {
        MyraOrbVisualizer(
            isSpeaking = isSpeaking,
            isListening = isListening,
            size = 240.dp,
            onClick = onOrbClick
        )
    }
}
