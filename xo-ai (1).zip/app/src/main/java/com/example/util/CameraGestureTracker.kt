package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.media.AudioManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.Executors
import kotlin.math.atan2

class CameraGestureTracker(private val context: Context) {

    private val cameraExecutor = Executors.newSingleThreadExecutor()

    private val _gestureState = MutableStateFlow("Idle")
    val gestureState: StateFlow<String> = _gestureState.asStateFlow()

    private val _lastAction = MutableStateFlow("None")
    val lastAction: StateFlow<String> = _lastAction.asStateFlow()

    private val pointHistory = mutableListOf<Pair<Float, Float>>()
    private val maxHistory = 12

    private var onCancelSpeechCallback: (() -> Unit)? = null

    fun setOnCancelSpeechListener(listener: () -> Unit) {
        onCancelSpeechCallback = listener
    }

    fun startTracking(lifecycleOwner: LifecycleOwner) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            try {
                val cameraProvider = cameraProviderFuture.get()
                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()

                imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    processImageFrame(imageProxy)
                }

                val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, imageAnalysis)
                _gestureState.value = "Vision Tracking Active"
            } catch (e: Exception) {
                _gestureState.value = "Camera Unavailable: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun processImageFrame(imageProxy: ImageProxy) {
        try {
            val bitmap = imageProxy.toBitmap()
            val point = detectBrightestSkinCluster(bitmap)
            if (point != null) {
                synchronized(pointHistory) {
                    pointHistory.add(point)
                    if (pointHistory.size > maxHistory) {
                        pointHistory.removeAt(0)
                    }

                    if (pointHistory.size >= 8) {
                        analyzeCircularGesture()
                    }
                }
            }
        } catch (_: Exception) {
        } finally {
            imageProxy.close()
        }
    }

    private fun detectBrightestSkinCluster(bitmap: Bitmap): Pair<Float, Float>? {
        val width = bitmap.width
        val height = bitmap.height
        val step = 16
        var sumX = 0f
        var sumY = 0f
        var count = 0

        for (x in 0 until width step step) {
            for (y in 0 until height step step) {
                val pixel = bitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)

                // Simple skin tone / bright index finger pixel threshold
                if (r > 95 && g > 40 && b > 20 && r > g && r > b && (r - Math.min(g, b)) > 15) {
                    sumX += x
                    sumY += y
                    count++
                }
            }
        }

        return if (count > 10) {
            Pair(sumX / count, sumY / count)
        } else null
    }

    private fun analyzeCircularGesture() {
        var totalAngleChange = 0.0
        val center = computeCentroid(pointHistory)

        for (i in 0 until pointHistory.size - 1) {
            val p1 = pointHistory[i]
            val p2 = pointHistory[i + 1]

            val a1 = atan2((p1.second - center.second).toDouble(), (p1.first - center.first).toDouble())
            val a2 = atan2((p2.second - center.second).toDouble(), (p2.first - center.first).toDouble())

            var delta = a2 - a1
            while (delta > Math.PI) delta -= 2 * Math.PI
            while (delta < -Math.PI) delta += 2 * Math.PI

            totalAngleChange += delta
        }

        // Clockwise rotation (Cumulative angle change > 3.0 radians ~ 170 degrees)
        if (totalAngleChange > 3.0) {
            _gestureState.value = "Clockwise Twirl Detected"
            _lastAction.value = "Volume Up 🔊"
            adjustVolume(increase = true)
            pointHistory.clear()
        } else if (totalAngleChange < -3.0) {
            // Counter-Clockwise rotation
            _gestureState.value = "Counter-Clockwise Twirl Detected"
            _lastAction.value = "Volume Down & Mute / Stop Speech 🔉"
            adjustVolume(increase = false)
            onCancelSpeechCallback?.invoke()
            pointHistory.clear()
        }
    }

    private fun computeCentroid(points: List<Pair<Float, Float>>): Pair<Float, Float> {
        val avgX = points.map { it.first }.average().toFloat()
        val avgY = points.map { it.second }.average().toFloat()
        return Pair(avgX, avgY)
    }

    private fun adjustVolume(increase: Boolean) {
        try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            if (audioManager != null) {
                val direction = if (increase) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
                audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
            }
        } catch (_: Exception) {}
    }

    fun stop() {
        cameraExecutor.shutdown()
    }
}

// Convert ImageProxy to Bitmap helper
private fun ImageProxy.toBitmap(): Bitmap {
    val plane = planes[0]
    val buffer = plane.buffer
    val bytes = ByteArray(buffer.capacity())
    buffer.get(bytes)
    return android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        ?: Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
}
