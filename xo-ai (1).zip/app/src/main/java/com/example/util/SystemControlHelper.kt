package com.example.util

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import java.net.URLEncoder

object SystemControlHelper {

    fun setVolume(context: Context, percent: Int): String {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (audioManager != null) {
            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val newVolume = (maxVolume * (percent.coerceIn(0, 100) / 100f)).toInt()
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, AudioManager.FLAG_SHOW_UI)
            return "Media volume set to $percent%"
        }
        return "Unable to access AudioManager"
    }

    /**
     * Parses complex compound prompts (e.g. "open whatsapp and message dad I will be late")
     * into target app launches, dialer actions, or messaging intents.
     */
    fun processIntentCommand(context: Context, rawPrompt: String): String {
        val lower = rawPrompt.lowercase().trim()

        // 1. Calling / Phone dialer
        if (lower.startsWith("call ") || lower.startsWith("phone call ") || lower.startsWith("dial ")) {
            val contact = lower.replace(Regex("^(call|phone call|dial)\\s+"), "").trim()
            return makePhoneCall(context, contact)
        }

        // 2. Messaging / WhatsApp
        if (lower.startsWith("message ") || lower.startsWith("whatsapp ") || lower.startsWith("send message to ")) {
            val payload = lower.replace(Regex("^(message|whatsapp|send message to)\\s+"), "").trim()
            return sendWhatsAppOrSms(context, payload)
        }

        // 3. Compound command: "open <app> and <action>"
        if (lower.contains(" and ")) {
            val parts = lower.split(" and ", limit = 2)
            val firstPart = parts[0].trim()
            val secondPart = parts[1].trim()

            // Handle app launch from first part
            val appLaunchResult = openAppByName(context, firstPart)

            // Execute secondary action if it's a message or call
            if (secondPart.startsWith("message ") || secondPart.startsWith("tell ") || secondPart.startsWith("send ")) {
                val msgResult = sendWhatsAppOrSms(context, secondPart)
                return "$appLaunchResult $msgResult"
            }
            return appLaunchResult
        }

        // 4. Standard single app launch
        return openAppByName(context, rawPrompt)
    }

    fun makePhoneCall(context: Context, contactOrNumber: String): String {
        val cleanQuery = contactOrNumber.trim()
        val digits = cleanQuery.replace(Regex("[^0-9+]"), "")
        val dialUri = if (digits.length >= 3) Uri.parse("tel:$digits") else Uri.parse("tel:$cleanQuery")

        val intent = Intent(Intent.ACTION_DIAL, dialUri).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(intent)
            "Opening phone dialer for '$cleanQuery'..."
        } catch (_: Exception) {
            "Unable to open dialer."
        }
    }

    fun sendWhatsAppOrSms(context: Context, payload: String): String {
        val pm = context.packageManager
        var contact = payload
        var message = ""

        if (payload.contains(" saying ")) {
            val parts = payload.split(" saying ", limit = 2)
            contact = parts[0].trim()
            message = parts[1].trim()
        } else if (payload.contains(" tell ")) {
            val parts = payload.split(" tell ", limit = 2)
            contact = parts[0].trim()
            message = parts[1].trim()
        }

        val encodedMsg = try { URLEncoder.encode(message, "UTF-8") } catch (_: Exception) { "" }
        val waIntent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("https://api.whatsapp.com/send?text=$encodedMsg")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            `package` = "com.whatsapp"
        }

        if (waIntent.resolveActivity(pm) != null) {
            return try {
                context.startActivity(waIntent)
                "Opening WhatsApp to send message to '$contact'."
            } catch (_: Exception) {
                fallbackSms(context, message)
            }
        }
        return fallbackSms(context, message)
    }

    private fun fallbackSms(context: Context, message: String): String {
        val smsIntent = Intent(Intent.ACTION_VIEW).apply {
            data = Uri.parse("sms:")
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(smsIntent)
            "Opening SMS app with your message."
        } catch (_: Exception) {
            "Could not launch messaging application."
        }
    }

    fun openAppByName(context: Context, queryName: String): String {
        var q = queryName.lowercase().trim()
        q = q.replace(Regex("^(open|launch|start|please open|please launch)\\s+"), "").trim()

        val pm = context.packageManager

        // Known direct launcher intents for common apps
        val knownPackage = when {
            q.contains("youtube") -> "com.google.android.youtube"
            q.contains("whatsapp") -> "com.whatsapp"
            q.contains("spotify") -> "com.spotify.music"
            q.contains("chrome") -> "com.android.chrome"
            q.contains("instagram") -> "com.instagram.android"
            q.contains("telegram") -> "org.telegram.messenger"
            q.contains("maps") -> "com.google.android.apps.maps"
            q.contains("gmail") -> "com.google.android.gm"
            else -> null
        }

        if (knownPackage != null) {
            val intent = pm.getLaunchIntentForPackage(knownPackage)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return "Launching $q..."
            }
        }

        if (q.contains("camera")) {
            val cameraIntent = Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(cameraIntent)
                return "Opening Camera..."
            } catch (_: Exception) {}
        }

        if (q.contains("setting") || q.contains("settings")) {
            val settingsIntent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(settingsIntent)
                return "Opening Android Settings..."
            } catch (_: Exception) {}
        }

        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = pm.queryIntentActivities(mainIntent, 0)
        
        val matchedApp = apps.firstOrNull {
            val label = it.loadLabel(pm).toString()
            label.contains(q, ignoreCase = true) || it.activityInfo.packageName.contains(q, ignoreCase = true)
        }

        if (matchedApp != null) {
            val launchIntent = pm.getLaunchIntentForPackage(matchedApp.activityInfo.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return "Launching ${matchedApp.loadLabel(pm)}..."
            }
        }
        return "Application matching '$q' was not found on device."
    }

    fun toggleWifi(context: Context, enable: Boolean): String {
        val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return "Opening Wi-Fi controls to ${if (enable) "enable" else "disable"} Wi-Fi."
    }

    fun toggleBluetooth(context: Context, enable: Boolean): String {
        val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return "Opening Bluetooth settings to adjust connection."
    }

    fun openSettingsScreen(context: Context, action: String) {
        val intent = Intent(action).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "Cannot open settings page directly", Toast.LENGTH_SHORT).show()
        }
    }

    fun requestOverlayPermission(context: Context) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
