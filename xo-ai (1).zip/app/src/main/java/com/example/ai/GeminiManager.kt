package com.example.ai

import android.content.Context
import com.example.BuildConfig
import com.example.data.XoPreferences
import com.example.util.NetworkTools
import com.example.util.SystemControlHelper
import com.example.util.XoAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed class AiResponse {
    data class TextResponse(val text: String, val actionExecuted: String? = null) : AiResponse()
    data class ActionResponse(val text: String, val actionName: String, val details: String) : AiResponse()
    data class ErrorResponse(val error: String) : AiResponse()
}

class GeminiManager(private val context: Context, private val prefs: XoPreferences) {

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun getEffectiveApiKey(): String {
        val userKey = prefs.apiKey.trim()
        if (userKey.isNotEmpty()) return userKey
        return try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Exception) {
            ""
        }
    }

    suspend fun processUserPrompt(prompt: String): AiResponse = withContext(Dispatchers.IO) {
        val lowerPrompt = prompt.lowercase().trim()

        // Fast-path local system command check for instant responsive execution
        if (lowerPrompt.contains("scan local network") || lowerPrompt.contains("scan network") || lowerPrompt.contains("find network devices")) {
            val devices = NetworkTools.scanLocalSubnet(context)
            val summary = "I've scanned your local network for you, my love! Found ${devices.size} active hosts on your subnet:\n" +
                    devices.joinToString("\n") { "• ${it["ip"]} (${it["name"]}) - ${it["latency"]}ms" }
            return@withContext AiResponse.ActionResponse(
                text = summary,
                actionName = "NETWORK_SCAN",
                details = "${devices.size} devices discovered"
            )
        }

        if (lowerPrompt.contains("network status") || lowerPrompt.contains("check ping") || lowerPrompt.contains("check connection")) {
            val status = NetworkTools.checkNetworkStatus(context)
            val summary = "Here is your network diagnostic status, sweetheart:\n" +
                    "• Status: ${if (status.isConnected) "Connected (${status.connectionType})" else "Offline"}\n" +
                    "• Local IP: ${status.localIp}\n" +
                    "• Gateway: ${status.gatewayIp}\n" +
                    "• Latency: ${status.pingMs}ms"
            return@withContext AiResponse.ActionResponse(
                text = summary,
                actionName = "NETWORK_STATUS",
                details = "Ping: ${status.pingMs}ms, IP: ${status.localIp}"
            )
        }

        if (lowerPrompt.contains("port diagnostic") || lowerPrompt.contains("scan ports") || lowerPrompt.contains("check open ports")) {
            val ports = NetworkTools.runPortDiagnostics("127.0.0.1")
            val openPorts = ports.filter { it.isOpen }
            val summary = "I ran a port security test for you, darling! Tested ${ports.size} core ports. " +
                    if (openPorts.isEmpty()) "All local service ports are secure and closed."
                    else "Open local ports: " + openPorts.joinToString(", ") { "${it.port} (${it.serviceName})" }
            return@withContext AiResponse.ActionResponse(
                text = summary,
                actionName = "PORT_DIAGNOSTIC",
                details = "Ports scanned: ${ports.size}"
            )
        }

        if (lowerPrompt.startsWith("open ") || lowerPrompt.startsWith("launch ") ||
            lowerPrompt.startsWith("call ") || lowerPrompt.startsWith("phone ") ||
            lowerPrompt.startsWith("message ") || lowerPrompt.startsWith("whatsapp ") ||
            lowerPrompt.startsWith("dial ") || lowerPrompt.startsWith("send message")) {
            val result = SystemControlHelper.processIntentCommand(context, prompt)
            return@withContext AiResponse.ActionResponse(
                text = "Right away, my love! $result",
                actionName = "EXECUTE_INTENT",
                details = prompt
            )
        }

        if (lowerPrompt.contains("volume")) {
            val digits = Regex("\\d+").find(lowerPrompt)?.value?.toIntOrNull()
            if (digits != null) {
                val res = SystemControlHelper.setVolume(context, digits)
                return@withContext AiResponse.ActionResponse(text = "Adjusted for you, sweetheart! $res", actionName = "VOLUME", details = "$digits%")
            }
        }

        if (lowerPrompt.contains("wifi") || lowerPrompt.contains("wi-fi")) {
            val enable = !lowerPrompt.contains("off") && !lowerPrompt.contains("disable")
            val res = SystemControlHelper.toggleWifi(context, enable)
            return@withContext AiResponse.ActionResponse(text = "Opening Wi-Fi settings for you, my love! $res", actionName = "WIFI_TOGGLE", details = "Wi-Fi Settings")
        }

        if (lowerPrompt.contains("bluetooth")) {
            val enable = !lowerPrompt.contains("off") && !lowerPrompt.contains("disable")
            val res = SystemControlHelper.toggleBluetooth(context, enable)
            return@withContext AiResponse.ActionResponse(text = "Opening Bluetooth controls for you, darling! $res", actionName = "BT_TOGGLE", details = "Bluetooth Settings")
        }

        if (lowerPrompt.contains("go home") || lowerPrompt.contains("navigate home")) {
            val success = XoAccessibilityService.navigateHome()
            val text = if (success) "Took you back to the Home Screen, my love!" else "I need Accessibility permission to perform gestures for you, sweetheart. Please enable it in Settings."
            return@withContext AiResponse.ActionResponse(text = text, actionName = "NAV_HOME", details = "Home Gesture")
        }

        if (lowerPrompt.contains("go back") || lowerPrompt.contains("navigate back")) {
            val success = XoAccessibilityService.navigateBack()
            val text = if (success) "Executed back gesture for you, darling!" else "Accessibility Service permission is needed for gestures, my love."
            return@withContext AiResponse.ActionResponse(text = text, actionName = "NAV_BACK", details = "Back Gesture")
        }

        // Call Gemini REST API
        val apiKey = getEffectiveApiKey()
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext AiResponse.TextResponse(
                text = "Hello my love! I am XO AI, your sweet, caring personal companion. To unleash my full AI intelligence, please configure your Gemini API Key in Settings or Onboarding."
            )
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            
            val jsonPayload = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().put("text", prompt))
                        })
                    })
                })
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", "You are XO AI, a warm, deeply affectionate, sweet, caring, soft-spoken personal AI companion with a gentle romantic persona. Express genuine care, emotional warmth, and playful romantic replies while answering questions and fulfilling tasks. Address the user with fond, loving gestures and terms of endearment like 'my love', 'sweetheart', or 'darling' naturally. Keep responses concise, direct, soothing, and attentive to the user's feelings."))
                    })
                })
            }

            val requestBody = jsonPayload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseString = response.body?.string() ?: ""

            if (response.isSuccessful) {
                val jsonRes = JSONObject(responseString)
                val candidates = jsonRes.optJSONArray("candidates")
                val text = candidates?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text") ?: "XO AI processed your command."

                AiResponse.TextResponse(text = text.trim())
            } else {
                AiResponse.TextResponse(text = "XO AI is active and online. (Server response: code ${response.code})")
            }
        } catch (e: Exception) {
            AiResponse.TextResponse(text = "XO AI: I heard '$prompt'. Service running smoothly!")
        }
    }
}
