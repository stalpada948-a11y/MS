package com.example.services

import android.app.Notification
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.widget.Toast

class XoNotificationListenerService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        super.onNotificationPosted(sbn)
        val pkg = sbn?.packageName ?: return

        // Intercept WhatsApp notifications
        if (pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b") {
            val extras = sbn.notification?.extras ?: return
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: ""
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""

            if (text.isNotBlank() && !title.lowercase().contains("whatsapp") && !text.contains("messages from")) {
                lastWhatsAppSender = title
                lastWhatsAppMessage = text
                lastWhatsAppSbn = sbn

                // Automatically read out WhatsApp message to user via TTS
                val speechManager = SpeechManager(applicationContext)
                speechManager.speak("WhatsApp message from $title. $text. Would you like to reply, my love?")
            }
        }
    }

    companion object {
        var lastWhatsAppSender: String = ""
        var lastWhatsAppMessage: String = ""
        var lastWhatsAppSbn: StatusBarNotification? = null

        fun sendAutoReply(context: Context, replyText: String): Boolean {
            val sbn = lastWhatsAppSbn ?: return false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val actions = sbn.notification.actions ?: return false
                for (action in actions) {
                    val remoteInputs = action.remoteInputs ?: continue
                    for (remoteInput in remoteInputs) {
                        val intent = Intent()
                        val bundle = Bundle().apply {
                            putCharSequence(remoteInput.resultKey, replyText)
                        }
                        android.app.RemoteInput.addResultsToIntent(arrayOf(remoteInput), intent, bundle)
                        try {
                            action.actionIntent.send(context, 0, intent)
                            Toast.makeText(context, "Replied via WhatsApp!", Toast.LENGTH_SHORT).show()
                            return true
                        } catch (_: Exception) {}
                    }
                }
            }
            return false
        }
    }
}
