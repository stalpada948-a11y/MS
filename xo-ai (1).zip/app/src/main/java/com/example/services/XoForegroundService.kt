package com.example.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class XoForegroundService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingOverlayView: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private var backgroundSpeechRecognizer: SpeechRecognizer? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        _isServiceRunning.value = true
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(
                    NOTIFICATION_ID,
                    buildNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(
                    NOTIFICATION_ID,
                    buildNotification(),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
                )
            }
        } else {
            startForeground(NOTIFICATION_ID, buildNotification())
        }

        showFloatingOverlayWindow()
        startBackgroundWakeWordListener()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP_SERVICE) {
            removeFloatingOverlayWindow()
            stopBackgroundWakeWordListener()
            stopSelf()
            return START_NOT_STICKY
        }
        _isServiceRunning.value = true
        showFloatingOverlayWindow()
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        _isServiceRunning.value = false
        removeFloatingOverlayWindow()
        stopBackgroundWakeWordListener()
    }

    private fun showFloatingOverlayWindow() {
        if (!Settings.canDrawOverlays(this) || floatingOverlayView != null) return

        try {
            windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager

            val overlayView = FrameLayout(this).apply {
                setPadding(24, 16, 24, 16)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 60f
                    setColor(0xFF0F1713.toInt())
                    setStroke(3, 0xFF00FF66.toInt())
                }

                val tv = TextView(context).apply {
                    text = "● XO AI"
                    setTextColor(0xFF00FF66.toInt())
                    textSize = 14f
                    setPadding(12, 6, 12, 6)
                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                }
                addView(tv)
            }

            val layoutParams = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    WindowManager.LayoutParams.TYPE_PHONE
                },
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = 50
                y = 200
            }

            var initialX = 0
            var initialY = 0
            var initialTouchX = 0f
            var initialTouchY = 0f
            var isClick = true

            overlayView.setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isClick = true
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.abs(dx) > 10 || Math.abs(dy) > 10) {
                            isClick = false
                        }
                        layoutParams.x = initialX + dx
                        layoutParams.y = initialY + dy
                        windowManager?.updateViewLayout(overlayView, layoutParams)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (isClick) {
                            val intent = Intent(this, MainActivity::class.java).apply {
                                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                            }
                            startActivity(intent)
                        }
                        true
                    }
                    else -> false
                }
            }

            windowManager?.addView(overlayView, layoutParams)
            floatingOverlayView = overlayView
        } catch (_: Exception) {}
    }

    private fun removeFloatingOverlayWindow() {
        try {
            if (floatingOverlayView != null) {
                windowManager?.removeView(floatingOverlayView)
                floatingOverlayView = null
            }
        } catch (_: Exception) {}
    }

    private fun startBackgroundWakeWordListener() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return

        try {
            backgroundSpeechRecognizer?.destroy()
        } catch (_: Exception) {}

        backgroundSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {
                    restartBackgroundListening()
                }

                override fun onError(error: Int) {
                    restartBackgroundListening()
                }

                override fun onResults(results: Bundle?) {
                    processRecognizedSpeech(results)
                    restartBackgroundListening()
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    processRecognizedSpeech(partialResults)
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
        }

        startListeningIntent()
    }

    private fun startListeningIntent() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        try {
            backgroundSpeechRecognizer?.startListening(intent)
        } catch (_: Exception) {}
    }

    private fun restartBackgroundListening() {
        handler.postDelayed({
            if (_isServiceRunning.value) {
                startListeningIntent()
            }
        }, 1500)
    }

    private fun stopBackgroundWakeWordListener() {
        try {
            backgroundSpeechRecognizer?.stopListening()
            backgroundSpeechRecognizer?.destroy()
            backgroundSpeechRecognizer = null
        } catch (_: Exception) {}
    }

    private fun processRecognizedSpeech(bundle: Bundle?) {
        val matches = bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        if (!matches.isNullOrEmpty()) {
            val text = matches[0].lowercase()
            if (text.contains("xo") || text.contains("hey xo") || text.contains("hello xo") || text.contains("ekso")) {
                val launchIntent = Intent(this, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    putExtra("WAKE_WORD_TRIGGERED", true)
                }
                startActivity(launchIntent)
            }
        }
    }

    private fun buildNotification(): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("XO AI Active")
            .setContentText("Your Intelligent Companion is listening and ready.")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "XO AI Background Assistant",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps XO AI active in the background for instant hotword activation and dynamic overlay."
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "xo_ai_service_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP_SERVICE = "com.example.xoai.STOP_SERVICE"

        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        fun startService(context: Context) {
            val intent = Intent(context, XoForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, XoForegroundService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            context.startService(intent)
        }
    }
}
