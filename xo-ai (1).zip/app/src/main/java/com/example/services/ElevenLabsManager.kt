package com.example.services

import android.content.Context
import android.media.MediaPlayer
import com.example.data.XoPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

class ElevenLabsManager(
    private val context: Context,
    private val prefs: XoPreferences
) {
    private val client = OkHttpClient()
    private var mediaPlayer: MediaPlayer? = null

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    suspend fun speak(text: String, onFallbackNeeded: () -> Unit = {}): Boolean = withContext(Dispatchers.IO) {
        val apiKey = prefs.elevenLabsApiKey.ifBlank { System.getenv("ELEVENLABS_API_KEY") ?: "" }
        if (apiKey.isBlank()) {
            withContext(Dispatchers.Main) { onFallbackNeeded() }
            return@withContext false
        }

        val voiceId = prefs.elevenLabsVoiceId.ifBlank { "21m00Tcm4TlvDq8ikWAM" } // Rachel / Myra
        val url = "https://api.elevenlabs.io/v1/text-to-speech/$voiceId"

        val json = JSONObject().apply {
            put("text", text)
            put("model_id", "eleven_monolingual_v1")
            put("voice_settings", JSONObject().apply {
                put("stability", 0.5)
                put("similarity_boost", 0.75)
            })
        }

        val body = json.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(url)
            .addHeader("xi-api-key", apiKey)
            .addHeader("Accept", "audio/mpeg")
            .post(body)
            .build()

        return@withContext try {
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val responseBody = response.body
                if (responseBody != null) {
                    val tempFile = File(context.cacheDir, "elevenlabs_temp_${System.currentTimeMillis()}.mp3")
                    val fos = FileOutputStream(tempFile)
                    fos.write(responseBody.bytes())
                    fos.close()

                    withContext(Dispatchers.Main) {
                        playAudioFile(tempFile)
                    }
                    true
                } else {
                    withContext(Dispatchers.Main) { onFallbackNeeded() }
                    false
                }
            } else {
                withContext(Dispatchers.Main) { onFallbackNeeded() }
                false
            }
        } catch (_: Exception) {
            withContext(Dispatchers.Main) { onFallbackNeeded() }
            false
        }
    }

    private fun playAudioFile(file: File) {
        stop()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(file.absolutePath)
            prepare()
            setOnCompletionListener {
                _isSpeaking.value = false
                try { file.delete() } catch (_: Exception) {}
            }
            setOnErrorListener { _, _, _ ->
                _isSpeaking.value = false
                try { file.delete() } catch (_: Exception) {}
                true
            }
            start()
            _isSpeaking.value = true
        }
    }

    fun stop() {
        try {
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.stop()
            }
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (_: Exception) {}
        _isSpeaking.value = false
    }
}
