package com.example.services

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class SpeechManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context, this)
    private var isTtsReady = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _audioAmplitude = MutableStateFlow(0f)
    val audioAmplitude: StateFlow<Float> = _audioAmplitude.asStateFlow()

    private val _speechText = MutableStateFlow("")
    val speechText: StateFlow<String> = _speechText.asStateFlow()

    private var speechRecognizer: SpeechRecognizer? = null

    init {
        initSpeechRecognizer()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val hindiLocale = Locale("hi", "IN")
            val result = tts?.setLanguage(hindiLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.US
            }

            // Select Hindi / Indian Female Voice model
            try {
                val voices = tts?.voices
                val hindiFemaleVoice = voices?.firstOrNull { voice ->
                    (voice.locale.language == "hi" || voice.locale.country == "IN" || voice.name.lowercase().contains("hi-in")) &&
                            voice.name.lowercase().contains("female")
                } ?: voices?.firstOrNull { voice ->
                    voice.locale.language == "hi" || voice.locale.country == "IN" || voice.name.lowercase().contains("hi")
                } ?: voices?.firstOrNull { voice ->
                    voice.name.lowercase().contains("female") || voice.name.lowercase().contains("soft")
                }

                if (hindiFemaleVoice != null) {
                    tts?.voice = hindiFemaleVoice
                }
            } catch (_: Exception) {}

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }
            })
            isTtsReady = true
        }
    }

    fun speak(text: String, pitch: Float = 1.15f, rate: Float = 0.90f) {
        if (isTtsReady && text.isNotBlank()) {
            val spokenText = cleanTextForSpeech(text)
            if (spokenText.isNotBlank()) {
                tts?.setPitch(pitch)
                tts?.setSpeechRate(rate)
                tts?.speak(spokenText, TextToSpeech.QUEUE_FLUSH, null, "XO_TTS_ID_${System.currentTimeMillis()}")
            }
        }
    }

    private fun cleanTextForSpeech(input: String): String {
        var text = input
        // Remove asterisk actions e.g. *gently holds your hand*
        text = text.replace(Regex("\\*.*?\\*"), "")
        // Remove parenthetical actions e.g. (chuckles)
        text = text.replace(Regex("\\(.*?\\)"), "")
        // Remove bracketed actions e.g. [smiles]
        text = text.replace(Regex("\\[.*?\\]"), "")
        // Remove markdown headers and formatting symbols
        text = text.replace(Regex("[#_~`]"), "")
        // Clean up redundant spaces
        return text.replace(Regex("\\s+"), " ").trim()
    }

    fun stopSpeaking() {
        if (isTtsReady) {
            tts?.stop()
            _isSpeaking.value = false
        }
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        _isListening.value = true
                        _speechText.value = ""
                    }

                    override fun onBeginningOfSpeech() {}

                    override fun onRmsChanged(rmsdB: Float) {
                        // Normalize rmsdB (-2 to 12+) to 0.0 .. 1.0 for audio wave visualizer
                        val norm = ((rmsdB + 2f) / 14f).coerceIn(0.1f, 1.0f)
                        _audioAmplitude.value = norm
                    }

                    override fun onBufferReceived(buffer: ByteArray?) {}

                    override fun onEndOfSpeech() {
                        _isListening.value = false
                        _audioAmplitude.value = 0f
                    }

                    override fun onError(error: Int) {
                        _isListening.value = false
                        _audioAmplitude.value = 0f
                    }

                    override fun onResults(results: Bundle?) {
                        _isListening.value = false
                        _audioAmplitude.value = 0f
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            _speechText.value = matches[0]
                        }
                    }

                    override fun onPartialResults(partialResults: Bundle?) {
                        val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            _speechText.value = matches[0]
                        }
                    }

                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    fun startListening(onRecognized: (String) -> Unit = {}) {
        if (speechRecognizer == null) {
            initSpeechRecognizer()
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            _isListening.value = false
        }
    }

    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (_: Exception) {}
        _isListening.value = false
        _audioAmplitude.value = 0f
    }

    fun shutdown() {
        try {
            tts?.stop()
            tts?.shutdown()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
    }
}
