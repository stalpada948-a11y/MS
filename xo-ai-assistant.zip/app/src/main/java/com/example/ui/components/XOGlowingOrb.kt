package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.XOOrbState
import com.example.ui.theme.*

@Composable
fun XOGlowingOrb(
    orbState: XOOrbState,
    modifier: Modifier = Modifier,
    onSingleTap: () -> Unit,
    onDoubleTap: () -> Unit,
    onLongPress: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "OrbAnimation")

    // Pulse scale depending on orb state
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.92f,
        targetValue = if (orbState == XOOrbState.LISTENING || orbState == XOOrbState.SPEAKING) 1.15f else 1.03f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (orbState == XOOrbState.LISTENING) 600 else if (orbState == XOOrbState.SPEAKING) 800 else 2000,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseScale"
    )

    // Rotation angle for outer cyber ring
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing)
        ),
        label = "Rotation"
    )

    val orbColor = when (orbState) {
        XOOrbState.IDLE -> XONeonGreen
        XOOrbState.LISTENING -> XOCyberCyan
        XOOrbState.THINKING -> XOCyberPurple
        XOOrbState.SPEAKING -> XONeonGreenBright
        XOOrbState.EMERGENCY -> XOEmergencyRed
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .testTag("xo_floating_orb")
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { onSingleTap() },
                    onDoubleTap = { onDoubleTap() },
                    onLongPress = { onLongPress() }
                )
            }
    ) {
        // Outer Radial Glow Canvas
        Canvas(
            modifier = Modifier
                .size(110.dp)
                .scale(pulseScale)
        ) {
            val center = Offset(size.width / 2, size.height / 2)
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(orbColor.copy(alpha = 0.6f), orbColor.copy(alpha = 0.15f), Color.Transparent),
                    center = center,
                    radius = size.width / 1.8f
                ),
                radius = size.width / 2
            )
            // Outer rotating dotted tech ring
            drawCircle(
                color = orbColor.copy(alpha = 0.8f),
                radius = size.width / 2.3f,
                style = Stroke(width = 2.dp.toPx())
            )
        }

        // Inner Core Glass Ball
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(68.dp)
                .scale(pulseScale)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            orbColor.copy(alpha = 0.9f),
                            XOGlassSurface,
                            XOBlack
                        )
                    )
                )
                .border(2.dp, orbColor, CircleShape)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "XO",
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Color.White
                )

                Text(
                    text = when (orbState) {
                        XOOrbState.IDLE -> "READY"
                        XOOrbState.LISTENING -> "LISTENING"
                        XOOrbState.THINKING -> "THINKING"
                        XOOrbState.SPEAKING -> "SPEAKING"
                        XOOrbState.EMERGENCY -> "SOS"
                    },
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    fontSize = 8.sp,
                    color = orbColor,
                    fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
                )
            }
        }
    }
}
