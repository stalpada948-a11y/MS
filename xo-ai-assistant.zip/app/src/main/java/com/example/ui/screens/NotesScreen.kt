package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Note
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun NotesScreen(
    notes: List<String>,
    onAddNote: (String) -> Unit
) {
    var newNoteText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(XOBlack)
            .padding(16.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Note, contentDescription = null, tint = XOCyberCyan)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "NEURAL QUICK NOTES",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = XOCyberCyan
            )
        }

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = XOCardBorder)

        // Add Note Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = newNoteText,
                onValueChange = { newNoteText = it },
                placeholder = { Text("Write quick note...", color = XOTextMuted, fontSize = 12.sp) },
                modifier = Modifier.weight(1f),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = XOGlassSurface,
                    unfocusedContainerColor = XOGlassSurface,
                    focusedBorderColor = XOCyberCyan,
                    unfocusedBorderColor = XOCardBorder,
                    focusedTextColor = XOTextPrimary,
                    unfocusedTextColor = XOTextPrimary
                ),
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = {
                    if (newNoteText.isNotBlank()) {
                        onAddNote(newNoteText)
                        newNoteText = ""
                    }
                },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(XOCyberCyan)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add", tint = XOBlack)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(notes) { note ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, XOCyberCyan.copy(alpha = 0.3f), RoundedCornerShape(14.dp)),
                    color = XOGlassSurface
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(XOCyberCyan)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = note,
                            fontSize = 13.sp,
                            color = XOTextPrimary
                        )
                    }
                }
            }
        }
    }
}
