package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun EmergencyScreen(
    onTriggerEmergency: () -> Unit,
    onCallEmergency: () -> Unit,
    onToggleFlashlight: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(XOBlack)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, contentDescription = null, tint = XOEmergencyRed)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "XO EMERGENCY OVERRIDE",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = XOEmergencyRed
                )
            }

            Text(
                text = "SAFETY SOS PROTOCOL • VOICE COMMAND ACTIVE",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = XOTextMuted
            )
        }

        // Giant SOS Trigger Button
        Surface(
            modifier = Modifier
                .size(200.dp)
                .clip(CircleShape)
                .border(3.dp, XOEmergencyRed, CircleShape)
                .testTag("sos_giant_button"),
            color = XOEmergencyRed.copy(alpha = 0.15f)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                Button(
                    onClick = onTriggerEmergency,
                    colors = ButtonDefaults.buttonColors(containerColor = XOEmergencyRed),
                    modifier = Modifier.size(160.dp),
                    shape = CircleShape
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = XOBlack, modifier = Modifier.size(40.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "ACTIVATE\nSOS",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = XOBlack,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, XOEmergencyRed.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
                color = XOGlassSurface
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "VOICE TRIGGER: \"XO EMERGENCY\"",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = XOEmergencyRed
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "• Shares live GPS coordinates via SMS\n• Triggers loud emergency siren audio tone\n• Engages high-frequency camera strobe light\n• Dials emergency contacts",
                        fontSize = 11.sp,
                        color = XOTextSecondary
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onCallEmergency,
                    colors = ButtonDefaults.buttonColors(containerColor = XOEmergencyRed),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.PhoneInTalk, contentDescription = null, tint = XOBlack)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Dial 911 / SOS", color = XOBlack, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onToggleFlashlight,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, XONeonGreen)
                ) {
                    Icon(Icons.Default.FlashOn, contentDescription = null, tint = XONeonGreen)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Strobe Light", color = XONeonGreen, fontSize = 12.sp)
                }
            }
        }
    }
}
