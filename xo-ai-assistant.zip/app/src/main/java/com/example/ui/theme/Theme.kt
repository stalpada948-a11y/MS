package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val XODarkColorScheme = darkColorScheme(
    primary = XONeonGreen,
    onPrimary = XOBlack,
    primaryContainer = XOGlassSurface,
    onPrimaryContainer = XONeonGreenBright,
    secondary = XOCyberCyan,
    onSecondary = XOBlack,
    secondaryContainer = XODarkObsidian,
    onSecondaryContainer = XOCyberCyan,
    tertiary = XOCyberPurple,
    background = XOBlack,
    onBackground = XOTextPrimary,
    surface = XODarkObsidian,
    onSurface = XOTextPrimary,
    surfaceVariant = XOGlassSurface,
    onSurfaceVariant = XOTextSecondary,
    outline = XOCardBorder,
    error = XOEmergencyRed,
    onError = Color.White
)

private val XOLightColorScheme = lightColorScheme(
    primary = XONeonGreenDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0F7E9),
    onPrimaryContainer = XODarkObsidian,
    secondary = XOCyberCyan,
    background = Color(0xFFF4FAF5),
    onBackground = Color(0xFF0F2214),
    surface = Color.White,
    onSurface = Color(0xFF0F2214),
    outline = Color(0xFFB0D1B8)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to futuristic Dark Mode
    dynamicColor: Boolean = false, // Preserve brand neon black identity
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) XODarkColorScheme else XOLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
