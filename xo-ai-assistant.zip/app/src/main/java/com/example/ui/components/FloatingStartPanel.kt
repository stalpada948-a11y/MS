package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.XOTab
import com.example.ui.theme.*

data class StartPanelTile(
    val title: String,
    val icon: ImageVector,
    val tab: XOTab,
    val accentColor: Color
)

@Composable
fun FloatingStartPanel(
    isOpen: Boolean,
    onClose: () -> Unit,
    onSelectTab: (XOTab) -> Unit,
    onQuickAction: (String) -> Unit
) {
    AnimatedVisibility(
        visible = isOpen,
        enter = fadeIn() + slideInVertically { it / 2 },
        exit = fadeOut() + slideOutVertically { it / 2 }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.75f))
                .clickable { onClose() },
            contentAlignment = Alignment.BottomCenter
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.5.dp, XONeonGreen, RoundedCornerShape(24.dp))
                    .clickable(enabled = false) {}, // Prevent dismiss click inside
                color = XODarkObsidian
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "XO START PANEL",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = XONeonGreen
                            )
                        }

                        IconButton(
                            onClick = onClose,
                            modifier = Modifier.testTag("close_start_panel")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = XOTextSecondary)
                        }
                    }

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = XOCardBorder
                    )

                    // Navigation Tiles Grid
                    val tiles = listOf(
                        StartPanelTile("Home", Icons.Default.Home, XOTab.HOME, XONeonGreen),
                        StartPanelTile("AI Chat", Icons.Default.Chat, XOTab.CHAT, XOCyberCyan),
                        StartPanelTile("Voice Mode", Icons.Default.Mic, XOTab.VOICE, XONeonGreenBright),
                        StartPanelTile("Memory", Icons.Default.Psychology, XOTab.MEMORY, XOCyberPurple),
                        StartPanelTile("Automation", Icons.Default.AutoMode, XOTab.AUTOMATION, XOWarningGold),
                        StartPanelTile("Dashboard", Icons.Default.Dashboard, XOTab.DASHBOARD, XONeonGreen),
                        StartPanelTile("Notes", Icons.Default.Note, XOTab.NOTES, XOCyberCyan),
                        StartPanelTile("Settings", Icons.Default.Settings, XOTab.SETTINGS, XOTextSecondary),
                        StartPanelTile("Emergency", Icons.Default.Warning, XOTab.EMERGENCY, XOEmergencyRed)
                    )

                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 280.dp)
                    ) {
                        items(tiles) { tile ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(XOGlassSurface)
                                    .border(1.dp, tile.accentColor.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                                    .clickable {
                                        onSelectTab(tile.tab)
                                    }
                                    .padding(12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = tile.icon,
                                        contentDescription = tile.title,
                                        tint = tile.accentColor,
                                        modifier = Modifier.size(26.dp)
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = tile.title,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = XOTextPrimary,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Quick Command Chips
                    Text(
                        text = "QUICK COMMANDS",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = XOTextMuted,
                        modifier = Modifier.align(Alignment.Start)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SuggestionChip(
                            onClick = { onQuickAction("Toggle Flashlight") },
                            label = { Text("Torch", fontSize = 11.sp, color = XONeonGreen) },
                            icon = { Icon(Icons.Default.FlashOn, contentDescription = null, tint = XONeonGreen, modifier = Modifier.size(14.dp)) },
                            colors = SuggestionChipDefaults.suggestionChipColors(containerColor = XOGlassSurface),
                            border = SuggestionChipDefaults.suggestionChipBorder(enabled = true, borderColor = XOCardBorder)
                        )

                        SuggestionChip(
                            onClick = { onQuickAction("Good Morning") },
                            label = { Text("Briefing", fontSize = 11.sp, color = XOCyberCyan) },
                            icon = { Icon(Icons.Default.WbSunny, contentDescription = null, tint = XOCyberCyan, modifier = Modifier.size(14.dp)) },
                            colors = SuggestionChipDefaults.suggestionChipColors(containerColor = XOGlassSurface),
                            border = SuggestionChipDefaults.suggestionChipBorder(enabled = true, borderColor = XOCardBorder)
                        )

                        SuggestionChip(
                            onClick = { onQuickAction("XO Emergency") },
                            label = { Text("SOS", fontSize = 11.sp, color = XOEmergencyRed) },
                            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = XOEmergencyRed, modifier = Modifier.size(14.dp)) },
                            colors = SuggestionChipDefaults.suggestionChipColors(containerColor = XOGlassSurface),
                            border = SuggestionChipDefaults.suggestionChipBorder(enabled = true, borderColor = XOEmergencyRed)
                        )
                    }
                }
            }
        }
    }
}
