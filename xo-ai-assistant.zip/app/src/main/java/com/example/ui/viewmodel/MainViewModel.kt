package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.db.AutomationEntity
import com.example.data.db.MemoryEntity
import com.example.data.db.RecentCommandEntity
import com.example.data.model.*
import com.example.domain.ai.GeminiService
import com.example.domain.ai.XOAIEngine
import com.example.domain.speech.SpeechManager
import com.example.domain.system.SystemHardwareController
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val database = AppDatabase.getDatabase(application)
    val memoryDao = database.memoryDao()
    val automationDao = database.automationDao()
    val recentCommandDao = database.recentCommandDao()

    val hardwareController = SystemHardwareController(application)
    val geminiService = GeminiService()
    val aiEngine = XOAIEngine(geminiService, hardwareController, memoryDao, recentCommandDao)

    private val _currentTab = MutableStateFlow(XOTab.HOME)
    val currentTab: StateFlow<XOTab> = _currentTab.asStateFlow()

    private val _orbState = MutableStateFlow(XOOrbState.IDLE)
    val orbState: StateFlow<XOOrbState> = _orbState.asStateFlow()

    private val _isStartPanelOpen = MutableStateFlow(false)
    val isStartPanelOpen: StateFlow<Boolean> = _isStartPanelOpen.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                text = "XO AI online. All neural cores synced. Tap mic or say 'Hey XO' to command.",
                isUser = false
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _systemStats = MutableStateFlow(hardwareController.getLiveSystemStats())
    val systemStats: StateFlow<SystemStats> = _systemStats.asStateFlow()

    private val _userNotes = MutableStateFlow<List<String>>(
        listOf(
            "Sync dark mode preferences across all devices",
            "Review morning fitness telemetry",
            "Update XO AI memory backup vault"
        )
    )
    val userNotes: StateFlow<List<String>> = _userNotes.asStateFlow()

    // Settings
    val voicePitch = MutableStateFlow(0.80f)
    val voiceSpeed = MutableStateFlow(1.0f)
    val wakeWordEnabled = MutableStateFlow(true)
    val floatingOrbEnabled = MutableStateFlow(true)

    // Speech manager
    var speechManager: SpeechManager? = null

    val memories: StateFlow<List<MemoryEntity>> = memoryDao.getAllMemories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val automations: StateFlow<List<AutomationEntity>> = automationDao.getAllAutomations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentCommands: StateFlow<List<RecentCommandEntity>> = recentCommandDao.getRecentCommands()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        speechManager = SpeechManager(
            context = application,
            onVoiceResult = { voiceText ->
                processUserCommand(voiceText, isVoice = true)
            },
            onSpeechStateChanged = { speaking ->
                if (speaking) {
                    _orbState.value = XOOrbState.SPEAKING
                } else if (_orbState.value == XOOrbState.SPEAKING) {
                    _orbState.value = XOOrbState.IDLE
                }
            }
        )

        // Seed initial default automations & memories if empty
        viewModelScope.launch {
            memoryDao.getAllMemories().firstOrNull()?.let { list ->
                if (list.isEmpty()) {
                    memoryDao.insertMemory(MemoryEntity(category = "Personal", title = "User Name", content = "Operative"))
                    memoryDao.insertMemory(MemoryEntity(category = "Habit", title = "Morning Routine", content = "Fitness & Telemetry Review at 07:00 AM"))
                    memoryDao.insertMemory(MemoryEntity(category = "App", title = "Favorite Music App", content = "Spotify / YouTube Music"))
                }
            }

            automationDao.getAllAutomations().firstOrNull()?.let { list ->
                if (list.isEmpty()) {
                    automationDao.insertAutomation(
                        AutomationEntity(
                            title = "Good Morning Routine",
                            triggerPhrase = "Good Morning",
                            actionsSummary = "Weather briefing, battery telemetry, read calendar, set workout playlist",
                            isEnabled = true
                        )
                    )
                    automationDao.insertAutomation(
                        AutomationEntity(
                            title = "Good Night Routine",
                            triggerPhrase = "Good Night",
                            actionsSummary = "Set silent mode, set 7 AM alarm, optimize battery drain",
                            isEnabled = true
                        )
                    )
                    automationDao.insertAutomation(
                        AutomationEntity(
                            title = "Emergency Override",
                            triggerPhrase = "XO Emergency",
                            actionsSummary = "Siren, Flashlight strobe, Send SOS location SMS",
                            isEnabled = true
                        )
                    )
                }
            }
        }

        // Periodic system stats refresh
        viewModelScope.launch {
            while (true) {
                delay(3000)
                _systemStats.value = hardwareController.getLiveSystemStats()
            }
        }
    }

    fun selectTab(tab: XOTab) {
        _currentTab.value = tab
        _isStartPanelOpen.value = false
    }

    fun toggleStartPanel() {
        _isStartPanelOpen.value = !_isStartPanelOpen.value
    }

    fun startVoiceListening() {
        _orbState.value = XOOrbState.LISTENING
        speechManager?.startListening()
    }

    fun stopVoiceListening() {
        speechManager?.stopListening()
        _orbState.value = XOOrbState.IDLE
    }

    fun processUserCommand(commandText: String, isVoice: Boolean = false) {
        if (commandText.isBlank()) return

        val userMsg = ChatMessage(text = commandText, isUser = true)
        _chatMessages.value = _chatMessages.value + userMsg
        _orbState.value = XOOrbState.THINKING

        viewModelScope.launch {
            val response = aiEngine.processUserCommand(
                rawCommand = commandText,
                isVoice = isVoice,
                onActionExecuted = { action ->
                    if (action == "EMERGENCY") {
                        _currentTab.value = XOTab.EMERGENCY
                        _orbState.value = XOOrbState.EMERGENCY
                    }
                }
            )

            val aiMsg = ChatMessage(text = response, isUser = false)
            _chatMessages.value = _chatMessages.value + aiMsg

            if (_orbState.value != XOOrbState.EMERGENCY) {
                _orbState.value = XOOrbState.SPEAKING
            }

            speechManager?.speak(response)
        }
    }

    fun addNote(note: String) {
        if (note.isNotBlank()) {
            _userNotes.value = _userNotes.value + note
        }
    }

    fun addMemory(category: String, title: String, content: String) {
        viewModelScope.launch {
            memoryDao.insertMemory(
                MemoryEntity(
                    category = category,
                    title = title,
                    content = content
                )
            )
        }
    }

    fun deleteMemory(memory: MemoryEntity) {
        viewModelScope.launch {
            memoryDao.deleteMemory(memory)
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            memoryDao.clearAll()
        }
    }

    fun toggleAutomation(automation: AutomationEntity) {
        viewModelScope.launch {
            automationDao.updateAutomation(
                automation.copy(isEnabled = !automation.isEnabled)
            )
        }
    }

    fun triggerEmergency() {
        processUserCommand("XO Emergency", isVoice = false)
    }

    override fun onCleared() {
        super.onCleared()
        speechManager?.shutdown()
    }
}
