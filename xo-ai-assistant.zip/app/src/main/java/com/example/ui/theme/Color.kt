package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// XO AI Futuristic Black + Neon Green Palette
val XOBlack = Color(0xFF040705)
val XODarkObsidian = Color(0xFF09120B)
val XOGlassSurface = Color(0xFF102014)
val XOCardBorder = Color(0xFF1E3D26)

val XONeonGreen = Color(0xFF00FF66)
val XONeonGreenBright = Color(0xFF33FF85)
val XONeonGreenDark = Color(0xFF00B347)
val XONeonGlow = Color(0x3300FF66)

val XOCyberCyan = Color(0xFF00E5FF)
val XOCyberPurple = Color(0xFFB000FF)
val XOEmergencyRed = Color(0xFFFF3366)
val XOWarningGold = Color(0xFFFFCC00)

val XOTextPrimary = Color(0xFFE6F5EA)
val XOTextSecondary = Color(0xFF88A891)
val XOTextMuted = Color(0xFF4C6B55)
