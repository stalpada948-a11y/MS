package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChatMessage
import com.example.ui.theme.*

@Composable
fun AIChatScreen(
    messages: List<ChatMessage>,
    onSendMessage: (String) -> Unit,
    onMicClick: () -> Unit,
    isListening: Boolean
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(XOBlack)
            .padding(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.SmartToy, contentDescription = null, tint = XONeonGreen)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "XO AI CHAT CORE",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = XONeonGreen
            )
        }

        HorizontalDivider(
            modifier = Modifier.padding(vertical = 12.dp),
            color = XOCardBorder
        )

        // Messages List
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                ChatBubble(msg = msg)
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Quick Suggestion Chips
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            SuggestionChip(
                onClick = { onSendMessage("What's my battery?") },
                label = { Text("Battery status", fontSize = 10.sp, color = XOCyberCyan) },
                colors = SuggestionChipDefaults.suggestionChipColors(containerColor = XOGlassSurface),
                border = SuggestionChipDefaults.suggestionChipBorder(enabled = true, borderColor = XOCardBorder)
            )

            SuggestionChip(
                onClick = { onSendMessage("Good Morning") },
                label = { Text("Good Morning", fontSize = 10.sp, color = XONeonGreen) },
                colors = SuggestionChipDefaults.suggestionChipColors(containerColor = XOGlassSurface),
                border = SuggestionChipDefaults.suggestionChipBorder(enabled = true, borderColor = XOCardBorder)
            )

            SuggestionChip(
                onClick = { onSendMessage("Torch on") },
                label = { Text("Flashlight", fontSize = 10.sp, color = XONeonGreenBright) },
                colors = SuggestionChipDefaults.suggestionChipColors(containerColor = XOGlassSurface),
                border = SuggestionChipDefaults.suggestionChipBorder(enabled = true, borderColor = XOCardBorder)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Input Field Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Command XO...", color = XOTextMuted, fontSize = 13.sp) },
                modifier = Modifier
                    .weight(1f)
                    .testTag("chat_input_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = XOGlassSurface,
                    unfocusedContainerColor = XOGlassSurface,
                    focusedBorderColor = XONeonGreen,
                    unfocusedBorderColor = XOCardBorder,
                    focusedTextColor = XOTextPrimary,
                    unfocusedTextColor = XOTextPrimary
                ),
                shape = RoundedCornerShape(20.dp),
                singleLine = true
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = onMicClick,
                modifier = Modifier
                    .testTag("chat_mic_button")
                    .clip(CircleShape)
                    .background(if (isListening) XOCyberCyan else XOGlassSurface)
                    .border(1.dp, if (isListening) XOCyberCyan else XONeonGreen, CircleShape)
            ) {
                Icon(
                    Icons.Default.Mic,
                    contentDescription = "Mic Input",
                    tint = if (isListening) XOBlack else XONeonGreen
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        onSendMessage(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier
                    .testTag("send_button")
                    .clip(CircleShape)
                    .background(XONeonGreen)
            ) {
                Icon(Icons.Default.Send, contentDescription = "Send", tint = XOBlack)
            }
        }
    }
}

@Composable
fun ChatBubble(msg: ChatMessage) {
    val isUser = msg.isUser
    Box(
        modifier = Modifier.fillMaxWidth(),
        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 290.dp)
                .clip(
                    RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = if (isUser) 18.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 18.dp
                    )
                )
                .border(
                    1.dp,
                    if (isUser) XOCyberCyan.copy(alpha = 0.5f) else XONeonGreen.copy(alpha = 0.5f),
                    RoundedCornerShape(18.dp)
                ),
            color = if (isUser) Color(0xFF0C1B20) else XOGlassSurface
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = if (isUser) "OPERATIVE" else "XO AI",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isUser) XOCyberCyan else XONeonGreen
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = msg.text,
                    fontSize = 13.sp,
                    color = XOTextPrimary,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
