package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun SettingsScreen(
    voicePitch: Float,
    voiceSpeed: Float,
    wakeWordEnabled: Boolean,
    floatingOrbEnabled: Boolean,
    onVoicePitchChanged: (Float) -> Unit,
    onVoiceSpeedChanged: (Float) -> Unit,
    onWakeWordToggled: (Boolean) -> Unit,
    onFloatingOrbToggled: (Boolean) -> Unit,
    onClearMemories: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(XOBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Settings, contentDescription = null, tint = XOTextPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "XO SYSTEM SETTINGS",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = XOTextPrimary
                )
            }
            Text(
                text = "CONFIGURATIONS & SYSTEM OVERRIDES",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = XOTextMuted
            )
        }

        // Voice Engine Settings Card
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, XONeonGreen.copy(alpha = 0.4f), RoundedCornerShape(18.dp)),
                color = XOGlassSurface
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "DEEP MALE VOICE SYNTHESIZER",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = XONeonGreen
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Voice Pitch: ${String.format("%.2f", voicePitch)}", fontSize = 11.sp, color = XOTextSecondary)
                    Slider(
                        value = voicePitch,
                        onValueChange = onVoicePitchChanged,
                        valueRange = 0.5f..1.5f,
                        colors = SliderDefaults.colors(thumbColor = XONeonGreen, activeTrackColor = XONeonGreen)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Speech Rate: ${String.format("%.2f", voiceSpeed)}", fontSize = 11.sp, color = XOTextSecondary)
                    Slider(
                        value = voiceSpeed,
                        onValueChange = onVoiceSpeedChanged,
                        valueRange = 0.5f..1.5f,
                        colors = SliderDefaults.colors(thumbColor = XOCyberCyan, activeTrackColor = XOCyberCyan)
                    )
                }
            }
        }

        // Wake Word & Overlay Toggles
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, XOCyberCyan.copy(alpha = 0.4f), RoundedCornerShape(18.dp)),
                color = XOGlassSurface
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Always Ready Wake Words", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = XOTextPrimary)
                            Text("\"Hey XO\" • \"Wake up XO\"", fontSize = 10.sp, color = XOTextSecondary)
                        }
                        Switch(
                            checked = wakeWordEnabled,
                            onCheckedChange = onWakeWordToggled,
                            colors = SwitchDefaults.colors(checkedThumbColor = XOBlack, checkedTrackColor = XONeonGreen)
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = XOCardBorder)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Floating XO Orb Overlay", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = XOTextPrimary)
                            Text("Always running floating assistant", fontSize = 10.sp, color = XOTextSecondary)
                        }
                        Switch(
                            checked = floatingOrbEnabled,
                            onCheckedChange = onFloatingOrbToggled,
                            colors = SwitchDefaults.colors(checkedThumbColor = XOBlack, checkedTrackColor = XOCyberCyan)
                        )
                    }
                }
            }
        }

        // Privacy & Memory Clear
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .border(1.dp, XOEmergencyRed.copy(alpha = 0.4f), RoundedCornerShape(18.dp)),
                color = XOGlassSurface
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "PRIVACY & LOCAL DATA VAULT",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = XOEmergencyRed
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "All personal memories and chat logs are stored strictly on this device in encrypted local Room storage.",
                        fontSize = 11.sp,
                        color = XOTextSecondary
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = onClearMemories,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = XOEmergencyRed),
                        border = androidx.compose.foundation.BorderStroke(1.dp, XOEmergencyRed)
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null, tint = XOEmergencyRed)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Purge Local Memories", fontSize = 11.sp, color = XOEmergencyRed)
                    }
                }
            }
        }
    }
}
