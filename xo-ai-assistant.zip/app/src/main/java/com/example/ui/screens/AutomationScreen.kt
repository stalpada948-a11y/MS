package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.AutomationEntity
import com.example.ui.theme.*

@Composable
fun AutomationScreen(
    automations: List<AutomationEntity>,
    onToggleAutomation: (AutomationEntity) -> Unit,
    onRunRoutine: (triggerPhrase: String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(XOBlack)
            .padding(16.dp)
    ) {
        // Header
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoMode, contentDescription = null, tint = XOWarningGold)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "SYSTEM AUTOMATION & ROUTINES",
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = XOWarningGold
            )
        }

        Text(
            text = "SMART TRIGGER ENGINE • AUTO EXECUTOR",
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = XOTextMuted
        )

        HorizontalDivider(
            modifier = Modifier.padding(vertical = 12.dp),
            color = XOCardBorder
        )

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(automations) { item ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .border(1.dp, if (item.isEnabled) XOWarningGold.copy(alpha = 0.5f) else XOCardBorder, RoundedCornerShape(18.dp)),
                    color = XOGlassSurface
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.title,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = XOTextPrimary
                            )

                            Switch(
                                checked = item.isEnabled,
                                onCheckedChange = { onToggleAutomation(item) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = XOBlack,
                                    checkedTrackColor = XOWarningGold
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Trigger Word: \"${item.triggerPhrase}\"",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = XONeonGreen
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = item.actionsSummary,
                            fontSize = 11.sp,
                            color = XOTextSecondary
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = { onRunRoutine(item.triggerPhrase) },
                            colors = ButtonDefaults.buttonColors(containerColor = XOGlassSurface),
                            modifier = Modifier
                                .align(Alignment.End)
                                .border(1.dp, XOWarningGold, RoundedCornerShape(12.dp)),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Run", tint = XOWarningGold, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Test Execute", fontSize = 11.sp, color = XOWarningGold)
                        }
                    }
                }
            }
        }
    }
}
