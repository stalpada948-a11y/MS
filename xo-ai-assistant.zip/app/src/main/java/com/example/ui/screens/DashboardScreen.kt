package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SystemStats
import com.example.ui.theme.*

@Composable
fun DashboardScreen(
    systemStats: SystemStats,
    isFlashlightOn: Boolean,
    onToggleFlashlight: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(XOBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Dashboard, contentDescription = null, tint = XONeonGreen)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "DEVICE TELEMETRY DASHBOARD",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = XONeonGreen
                )
            }
            Text(
                text = "REALTIME HARDWARE MONITORS",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = XOTextMuted
            )
        }

        // CPU & Thermal Bar
        item {
            TelemetryBarCard(
                title = "CPU SYSTEM LOAD",
                value = "${systemStats.cpuUsagePct}%",
                progress = systemStats.cpuUsagePct / 100f,
                accentColor = XOCyberCyan,
                subtext = "Core Temp: ${systemStats.deviceTempC}°C"
            )
        }

        // RAM Usage Bar
        item {
            TelemetryBarCard(
                title = "RAM MEMORY OCCUPANCY",
                value = "${systemStats.ramUsedGb} / ${systemStats.ramTotalGb} GB",
                progress = (systemStats.ramUsedGb / systemStats.ramTotalGb).coerceIn(0f, 1f),
                accentColor = XONeonGreen,
                subtext = "Available: ${(systemStats.ramTotalGb - systemStats.ramUsedGb).toString().take(3)} GB"
            )
        }

        // Storage Space Bar
        item {
            TelemetryBarCard(
                title = "INTERNAL STORAGE CAPACITY",
                value = "${systemStats.storageUsedGb} / ${systemStats.storageTotalGb} GB",
                progress = (systemStats.storageUsedGb / systemStats.storageTotalGb).coerceIn(0f, 1f),
                accentColor = XOCyberPurple,
                subtext = "Free: ${(systemStats.storageTotalGb - systemStats.storageUsedGb).toInt()} GB"
            )
        }

        // Quick Hardware Toggles Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Flashlight Tile
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, if (isFlashlightOn) XONeonGreen else XOCardBorder, RoundedCornerShape(16.dp)),
                    color = XOGlassSurface
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.FlashOn,
                            contentDescription = "Flashlight",
                            tint = if (isFlashlightOn) XONeonGreen else XOTextSecondary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("FLASHLIGHT", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = XOTextMuted)
                        Spacer(modifier = Modifier.height(6.dp))
                        Button(
                            onClick = onToggleFlashlight,
                            colors = ButtonDefaults.buttonColors(containerColor = if (isFlashlightOn) XONeonGreen else XODarkObsidian),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                        ) {
                            Text(
                                if (isFlashlightOn) "ON" else "OFF",
                                fontSize = 11.sp,
                                color = if (isFlashlightOn) XOBlack else XOTextPrimary
                            )
                        }
                    }
                }

                // Network Tile
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, XOCyberCyan, RoundedCornerShape(16.dp)),
                    color = XOGlassSurface
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Wifi, contentDescription = "Wi-Fi", tint = XOCyberCyan)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("NETWORK", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = XOTextMuted)
                        Text(systemStats.wifiSsid, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = XOCyberCyan)
                    }
                }
            }
        }
    }
}

@Composable
fun TelemetryBarCard(
    title: String,
    value: String,
    progress: Float,
    accentColor: androidx.compose.ui.graphics.Color,
    subtext: String
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(18.dp)),
        color = XOGlassSurface
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(title, fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = XOTextMuted)
                Text(value, fontSize = 13.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = accentColor)
            }
            Spacer(modifier = Modifier.height(8.dp))
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = accentColor,
                trackColor = XODarkObsidian
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(subtext, fontSize = 10.sp, color = XOTextSecondary)
        }
    }
}
