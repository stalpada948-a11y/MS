package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SystemStats
import com.example.data.model.XOOrbState
import com.example.ui.components.XOGlowingOrb
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HomeScreen(
    orbState: XOOrbState,
    systemStats: SystemStats,
    recentCommands: List<com.example.data.db.RecentCommandEntity>,
    onMicClick: () -> Unit,
    onOpenStartPanel: () -> Unit,
    onQuickAction: (String) -> Unit,
    onNavigateTab: (com.example.data.model.XOTab) -> Unit
) {
    var currentTimeString by remember { mutableStateOf("") }
    var currentDateString by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            val now = Date()
            currentTimeString = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now)
            currentDateString = SimpleDateFormat("EEEE, MMM dd, yyyy", Locale.getDefault()).format(now)
            kotlinx.coroutines.delay(1000)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(XOBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Top HUD Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(XONeonGreen)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "XO SYSTEM V4.2",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = XONeonGreen
                        )
                    }
                    Text(
                        text = "ONLINE & SYNCED",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        color = XOTextMuted
                    )
                }

                IconButton(
                    onClick = onOpenStartPanel,
                    modifier = Modifier
                        .testTag("open_start_panel_button")
                        .clip(CircleShape)
                        .background(XOGlassSurface)
                        .border(1.dp, XONeonGreen, CircleShape)
                ) {
                    Icon(Icons.Default.Apps, contentDescription = "Start Panel", tint = XONeonGreen)
                }
            }
        }

        // 2. Main Glowing Orb Avatar Card
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, XOCardBorder, RoundedCornerShape(24.dp)),
                color = XODarkObsidian
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Digital Clock & Date
                    Text(
                        text = currentTimeString.ifEmpty { "12:00:00" },
                        fontFamily = FontFamily.Monospace,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Bold,
                        color = XONeonGreen,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = currentDateString.ifEmpty { "Wednesday, Aug 05, 2026" },
                        fontSize = 12.sp,
                        color = XOTextSecondary,
                        fontFamily = FontFamily.Monospace
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Floating Interactive XO Orb
                    XOGlowingOrb(
                        orbState = orbState,
                        onSingleTap = onOpenStartPanel,
                        onDoubleTap = onMicClick,
                        onLongPress = { onQuickAction("Good Morning") }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = when (orbState) {
                            XOOrbState.IDLE -> "Tap orb for Start Panel • Double tap for Voice"
                            XOOrbState.LISTENING -> "XO is listening to your command..."
                            XOOrbState.THINKING -> "Processing neural intent..."
                            XOOrbState.SPEAKING -> "XO Vocalizing response..."
                            XOOrbState.EMERGENCY -> "EMERGENCY PROTOCOL ACTIVE"
                        },
                        fontSize = 11.sp,
                        color = if (orbState == XOOrbState.EMERGENCY) XOEmergencyRed else XONeonGreenBright,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // 3. Hardware System Gauges Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Battery Gauge Card
                GaugeCard(
                    title = "BATTERY",
                    value = "${systemStats.batteryLevel}%",
                    subtext = if (systemStats.isCharging) "Charging" else "Optimal",
                    icon = Icons.Default.BatteryChargingFull,
                    accentColor = XONeonGreen,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(com.example.data.model.XOTab.DASHBOARD) }
                )

                // RAM Gauge Card
                GaugeCard(
                    title = "RAM",
                    value = "${systemStats.ramUsedGb} GB",
                    subtext = "of ${systemStats.ramTotalGb} GB",
                    icon = Icons.Default.Memory,
                    accentColor = XOCyberCyan,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(com.example.data.model.XOTab.DASHBOARD) }
                )

                // Storage Gauge Card
                GaugeCard(
                    title = "STORAGE",
                    value = "${systemStats.storageUsedGb} GB",
                    subtext = "Free ${(systemStats.storageTotalGb - systemStats.storageUsedGb).toInt()} GB",
                    icon = Icons.Default.Storage,
                    accentColor = XOCyberPurple,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(com.example.data.model.XOTab.DASHBOARD) }
                )
            }
        }

        // 4. Daily Briefing Card
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, XOCyberCyan.copy(alpha = 0.4f), RoundedCornerShape(20.dp)),
                color = XOGlassSurface
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = XOCyberCyan)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "DAILY BRIEFING",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = XOCyberCyan
                            )
                        }

                        TextButton(onClick = { onQuickAction("Good Morning") }) {
                            Text("Trigger", color = XONeonGreen, fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "• Weather: 24°C, Clear skies\n• Schedule: All morning tasks synchronized\n• Memory Vault: 3 preferences active\n• Device Power: Optimal state",
                        fontSize = 12.sp,
                        color = XOTextPrimary,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // 5. Quick Actions Row
        item {
            Text(
                text = "QUICK ACTIONS",
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                color = XOTextMuted
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionButton("Torch", Icons.Default.FlashOn, XONeonGreen, Modifier.weight(1f)) {
                    onQuickAction("flashlight on")
                }
                QuickActionButton("Call", Icons.Default.Phone, XOCyberCyan, Modifier.weight(1f)) {
                    onQuickAction("call")
                }
                QuickActionButton("Maps", Icons.Default.Map, XONeonGreenBright, Modifier.weight(1f)) {
                    onQuickAction("open maps")
                }
                QuickActionButton("SOS", Icons.Default.Warning, XOEmergencyRed, Modifier.weight(1f)) {
                    onQuickAction("XO Emergency")
                }
            }
        }

        // 6. Recent Commands Stream
        item {
            Text(
                text = "RECENT NEURAL COMMANDS",
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                color = XOTextMuted
            )
        }

        if (recentCommands.isEmpty()) {
            item {
                Text(
                    text = "No recent commands recorded. Speak or type to interact.",
                    fontSize = 12.sp,
                    color = XOTextSecondary
                )
            }
        } else {
            items(recentCommands.take(3)) { cmd ->
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, XOCardBorder, RoundedCornerShape(12.dp)),
                    color = XOGlassSurface
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "> ${cmd.commandText}",
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = XONeonGreen
                            )
                            if (cmd.isVoice) {
                                Icon(Icons.Default.Mic, contentDescription = "Voice", tint = XOCyberCyan, modifier = Modifier.size(14.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = cmd.responseText,
                            fontSize = 11.sp,
                            color = XOTextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GaugeCard(
    title: String,
    value: String,
    subtext: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            .clickable { onClick() },
        color = XOGlassSurface
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Icon(icon, contentDescription = title, tint = accentColor, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(title, fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = XOTextMuted)
            Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = XOTextPrimary, fontFamily = FontFamily.Monospace)
            Text(subtext, fontSize = 9.sp, color = XOTextSecondary)
        }
    }
}

@Composable
fun QuickActionButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
            .clickable { onClick() },
        color = XOGlassSurface
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = label, tint = color, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = XOTextPrimary, fontFamily = FontFamily.Monospace)
        }
    }
}
