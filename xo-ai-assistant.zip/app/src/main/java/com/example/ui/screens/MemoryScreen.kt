package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.MemoryEntity
import com.example.ui.theme.*

@Composable
fun MemoryScreen(
    memories: List<MemoryEntity>,
    onAddMemory: (category: String, title: String, content: String) -> Unit,
    onDeleteMemory: (MemoryEntity) -> Unit,
    onClearAll: () -> Unit
) {
    var selectedCategory by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }

    val categories = listOf("All", "Personal", "Family", "Habit", "App", "Work")

    val filteredMemories = memories.filter { mem ->
        (selectedCategory == "All" || mem.category.equals(selectedCategory, ignoreCase = true)) &&
                (searchQuery.isBlank() || mem.content.contains(searchQuery, ignoreCase = true) || mem.title.contains(searchQuery, ignoreCase = true))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(XOBlack)
            .padding(16.dp)
    ) {
        // Header Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Psychology, contentDescription = null, tint = XOCyberPurple)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "MEMORY ENGINE VAULT",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = XOCyberPurple
                )
            }

            IconButton(
                onClick = { showAddDialog = true },
                modifier = Modifier
                    .testTag("add_memory_button")
                    .clip(CircleShape)
                    .background(XOCyberPurple)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Memory", tint = XOBlack)
            }
        }

        Text(
            text = "ENCRYPTED LOCAL STORAGE • XO RECALL ENGINE",
            fontFamily = FontFamily.Monospace,
            fontSize = 9.sp,
            color = XOTextMuted
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search encrypted memories...", color = XOTextMuted, fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = XOTextSecondary) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("memory_search_field"),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = XOGlassSurface,
                unfocusedContainerColor = XOGlassSurface,
                focusedBorderColor = XOCyberPurple,
                unfocusedBorderColor = XOCardBorder,
                focusedTextColor = XOTextPrimary,
                unfocusedTextColor = XOTextPrimary
            ),
            shape = RoundedCornerShape(16.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filter Category Chips
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(categories) { cat ->
                FilterChip(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    label = { Text(cat, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = XOCyberPurple,
                        selectedLabelColor = XOBlack,
                        containerColor = XOGlassSurface,
                        labelColor = XOTextPrimary
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Memories List
        if (filteredMemories.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Lock, contentDescription = null, tint = XOTextMuted, modifier = Modifier.size(40.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No memories stored in this category.\nSay 'XO remember that...' or tap + to add.",
                        fontSize = 12.sp,
                        color = XOTextSecondary,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredMemories) { mem ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, XOCyberPurple.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                        color = XOGlassSurface
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = mem.category.uppercase(),
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        color = XOCyberPurple
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(Icons.Default.Lock, contentDescription = "Encrypted", tint = XONeonGreen, modifier = Modifier.size(10.dp))
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = mem.content,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = XOTextPrimary
                                )
                            }

                            IconButton(onClick = { onDeleteMemory(mem) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = XOEmergencyRed)
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Memory Dialog
    if (showAddDialog) {
        var catInput by remember { mutableStateOf("Personal") }
        var titleInput by remember { mutableStateOf("") }
        var contentInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            containerColor = XODarkObsidian,
            title = {
                Text("STORE NEW MEMORY", fontFamily = FontFamily.Monospace, color = XOCyberPurple, fontSize = 16.sp)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = catInput,
                        onValueChange = { catInput = it },
                        label = { Text("Category (Personal/Habit/App/Family)") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = XOCyberPurple)
                    )
                    OutlinedTextField(
                        value = contentInput,
                        onValueChange = { contentInput = it },
                        label = { Text("Memory Content (e.g., Favorite coffee is Espresso)") },
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = XOCyberPurple)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (contentInput.isNotBlank()) {
                            onAddMemory(catInput, titleInput.ifBlank { "Preference" }, contentInput)
                            showAddDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = XOCyberPurple)
                ) {
                    Text("Encrypt & Save", color = XOBlack)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel", color = XOTextSecondary)
                }
            }
        )
    }
}
