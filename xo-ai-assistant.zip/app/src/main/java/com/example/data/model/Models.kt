package com.example.data.model

enum class XOOrbState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    EMERGENCY
}

enum class XOTab {
    HOME,
    CHAT,
    VOICE,
    MEMORY,
    AUTOMATION,
    DASHBOARD,
    NOTES,
    SETTINGS,
    EMERGENCY
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val isSystemAction: Boolean = false
)

data class SystemStats(
    val batteryLevel: Int = 88,
    val isCharging: Boolean = false,
    val ramUsedGb: Float = 4.2f,
    val ramTotalGb: Float = 8.0f,
    val storageUsedGb: Float = 62.5f,
    val storageTotalGb: Float = 128.0f,
    val isWifiConnected: Boolean = true,
    val wifiSsid: String = "XO_Cyber_5G",
    val isBluetoothEnabled: Boolean = true,
    val cpuUsagePct: Int = 18,
    val deviceTempC: Float = 34.5f
)

data class QuickAction(
    val title: String,
    val iconName: String,
    val command: String,
    val category: String
)
