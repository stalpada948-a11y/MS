package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String, // "Personal", "Family", "App", "Habit", "Work", "Preference"
    val title: String,
    val content: String,
    val isEncrypted: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "automations")
data class AutomationEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val triggerPhrase: String,
    val actionsSummary: String,
    val isEnabled: Boolean = true,
    val lastTriggered: Long = 0
)

@Entity(tableName = "recent_commands")
data class RecentCommandEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val commandText: String,
    val responseText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isVoice: Boolean = false
)
