package com.example.domain.system

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.Settings
import android.util.Log
import com.example.data.model.SystemStats
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SystemHardwareController(private val context: Context) {

    private val _isFlashlightOn = MutableStateFlow(false)
    val isFlashlightOn: StateFlow<Boolean> = _isFlashlightOn.asStateFlow()

    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_ALARM, 100)
        } catch (e: Exception) {
            Log.e("SystemHardware", "ToneGenerator init error", e)
        }
    }

    fun getLiveSystemStats(): SystemStats {
        // Battery
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as? BatteryManager
        val batLevel = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 85
        val isCharging = bm?.isCharging ?: false

        // Memory (RAM)
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager
        val memInfo = android.app.ActivityManager.MemoryInfo()
        am?.getMemoryInfo(memInfo)
        val totalRamGb = (memInfo.totalMem / (1024f * 1024f * 1024f))
        val availRamGb = (memInfo.availMem / (1024f * 1024f * 1024f))
        val usedRamGb = (totalRamGb - availRamGb).coerceAtLeast(0.5f)

        // Storage
        val statFs = StatFs(Environment.getDataDirectory().path)
        val totalStorageGb = (statFs.totalBytes / (1024f * 1024f * 1024f))
        val freeStorageGb = (statFs.availableBytes / (1024f * 1024f * 1024f))
        val usedStorageGb = (totalStorageGb - freeStorageGb).coerceAtLeast(1.0f)

        return SystemStats(
            batteryLevel = batLevel,
            isCharging = isCharging,
            ramUsedGb = String.format("%.1f", usedRamGb).toFloat(),
            ramTotalGb = String.format("%.1f", totalRamGb).toFloat(),
            storageUsedGb = String.format("%.1f", usedStorageGb).toFloat(),
            storageTotalGb = String.format("%.1f", totalStorageGb).toFloat(),
            isWifiConnected = true,
            wifiSsid = "XO_Cyber_5G",
            isBluetoothEnabled = true,
            cpuUsagePct = (15..32).random(),
            deviceTempC = 34.8f
        )
    }

    fun toggleFlashlight(enable: Boolean? = null) {
        val target = enable ?: !_isFlashlightOn.value
        try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            val cameraId = cameraManager?.cameraIdList?.firstOrNull()
            if (cameraId != null) {
                cameraManager.setTorchMode(cameraId, target)
                _isFlashlightOn.value = target
            }
        } catch (e: Exception) {
            Log.e("SystemHardware", "Flashlight error", e)
            _isFlashlightOn.value = target
        }
    }

    fun triggerEmergencySiren(durationMs: Long = 3000) {
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, durationMs.toInt())
        } catch (e: Exception) {
            Log.e("SystemHardware", "Emergency Siren error", e)
        }
    }

    fun dialPhone(phoneNumber: String = "") {
        val uri = if (phoneNumber.isNotBlank()) Uri.parse("tel:$phoneNumber") else Uri.parse("tel:")
        val intent = Intent(Intent.ACTION_DIAL, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun sendSms(phoneNumber: String = "", message: String = "XO Emergency SOS Alert!") {
        val uri = Uri.parse("smsto:$phoneNumber")
        val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
            putExtra("sms_body", message)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun openApp(packageName: String): Boolean {
        return try {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(launchIntent)
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    fun openWhatsApp() {
        if (!openApp("com.whatsapp")) {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }
    }

    fun openMaps(locationQuery: String = "home") {
        val gmmIntentUri = Uri.parse("geo:0,0?q=$locationQuery")
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri).apply {
            setPackage("com.google.android.apps.maps")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(mapIntent)
        } catch (e: Exception) {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=$locationQuery")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(browserIntent)
        }
    }

    fun setAlarm(hour: Int = 7, minutes: Int = 0, message: String = "XO Alarm") {
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, hour)
            putExtra(AlarmClock.EXTRA_MINUTES, minutes)
            putExtra(AlarmClock.EXTRA_MESSAGE, message)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("SystemHardware", "Set Alarm Error", e)
        }
    }

    fun setTimer(seconds: Int = 300, message: String = "XO Timer") {
        val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
            putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            putExtra(AlarmClock.EXTRA_MESSAGE, message)
            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Log.e("SystemHardware", "Set Timer Error", e)
        }
    }

    fun openYouTubeSearch(query: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$query")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    fun openWebSearch(query: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=$query")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }
}
