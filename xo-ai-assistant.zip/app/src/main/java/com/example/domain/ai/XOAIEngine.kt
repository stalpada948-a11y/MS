package com.example.domain.ai

import com.example.data.db.MemoryDao
import com.example.data.db.MemoryEntity
import com.example.data.db.RecentCommandDao
import com.example.data.db.RecentCommandEntity
import com.example.data.model.SystemStats
import com.example.domain.system.SystemHardwareController
import kotlinx.coroutines.flow.firstOrNull

class XOAIEngine(
    private val geminiService: GeminiService,
    private val hardwareController: SystemHardwareController,
    private val memoryDao: MemoryDao,
    private val recentCommandDao: RecentCommandDao
) {

    suspend fun processUserCommand(
        rawCommand: String,
        isVoice: Boolean = false,
        onActionExecuted: (String) -> Unit = {}
    ): String {
        val command = rawCommand.trim()
        if (command.isBlank()) return "Awaiting command..."

        val lower = command.lowercase()

        // 1. System Hardware Commands
        if (lower.contains("flashlight on") || lower.contains("turn on flashlight") || lower.contains("torch on")) {
            hardwareController.toggleFlashlight(true)
            val resp = "Flashlight engaged."
            saveHistory(command, resp, isVoice)
            onActionExecuted("FLASHLIGHT_ON")
            return resp
        }

        if (lower.contains("flashlight off") || lower.contains("turn off flashlight") || lower.contains("torch off")) {
            hardwareController.toggleFlashlight(false)
            val resp = "Flashlight disengaged."
            saveHistory(command, resp, isVoice)
            onActionExecuted("FLASHLIGHT_OFF")
            return resp
        }

        if (lower.contains("emergency") || lower.contains("sos")) {
            hardwareController.triggerEmergencySiren(4000)
            hardwareController.toggleFlashlight(true)
            hardwareController.sendSms("", "XO EMERGENCY SOS ALERT! User triggered voice emergency override.")
            val resp = "EMERGENCY PROTOCOL ACTIVATED. Siren engaged, flashlight strobe active, SOS alert dispatched."
            saveHistory(command, resp, isVoice)
            onActionExecuted("EMERGENCY")
            return resp
        }

        if (lower.contains("call dad") || lower.contains("call mom") || lower.contains("call ") || lower == "call") {
            val contactName = command.substringAfter("call", "").trim()
            hardwareController.dialPhone("")
            val resp = if (contactName.isNotBlank()) "Initiating call protocol to $contactName." else "Opening phone dialer."
            saveHistory(command, resp, isVoice)
            onActionExecuted("CALL")
            return resp
        }

        if (lower.contains("open whatsapp")) {
            hardwareController.openWhatsApp()
            val resp = "Launching WhatsApp application."
            saveHistory(command, resp, isVoice)
            onActionExecuted("OPEN_APP")
            return resp
        }

        if (lower.contains("navigate home") || lower.contains("open maps") || lower.contains("navigate to")) {
            val destination = command.substringAfter("navigate to", "home").trim()
            hardwareController.openMaps(destination)
            val resp = "Plotting navigation route to $destination."
            saveHistory(command, resp, isVoice)
            onActionExecuted("MAPS")
            return resp
        }

        if (lower.contains("set an alarm") || lower.contains("set alarm") || lower.contains("wake me up")) {
            hardwareController.setAlarm(7, 0, "XO Morning Command")
            val resp = "Alarm configured for 07:00 AM."
            saveHistory(command, resp, isVoice)
            onActionExecuted("ALARM")
            return resp
        }

        if (lower.contains("timer") || lower.contains("set a timer")) {
            hardwareController.setTimer(300, "XO 5 Min Timer")
            val resp = "5-minute timer countdown started."
            saveHistory(command, resp, isVoice)
            onActionExecuted("TIMER")
            return resp
        }

        if (lower.contains("battery") || lower.contains("power level")) {
            val stats = hardwareController.getLiveSystemStats()
            val resp = "Battery telemetry: ${stats.batteryLevel}% ${if (stats.isCharging) "(Charging)" else "(Discharging)"}. System power is stable."
            saveHistory(command, resp, isVoice)
            onActionExecuted("BATTERY")
            return resp
        }

        if (lower.contains("good morning")) {
            val stats = hardwareController.getLiveSystemStats()
            val resp = "Good morning, Operative. Weather is 24°C and clear. Battery is at ${stats.batteryLevel}%. RAM load is ${stats.ramUsedGb} GB. Today's schedule is clear and ready."
            saveHistory(command, resp, isVoice)
            onActionExecuted("GOOD_MORNING")
            return resp
        }

        if (lower.contains("good night")) {
            hardwareController.setAlarm(7, 0, "XO Morning Wakeup")
            val resp = "Good night, Operative. Alarms configured for 07:00 AM. Enabling silent power-saving protocol."
            saveHistory(command, resp, isVoice)
            onActionExecuted("GOOD_NIGHT")
            return resp
        }

        if (lower.startsWith("xo search") || lower.contains("google search") || lower.startsWith("search ")) {
            val query = command.replace("xo search", "").replace("search", "").trim()
            hardwareController.openWebSearch(query)
            val resp = "Executing global web search for '$query'."
            saveHistory(command, resp, isVoice)
            onActionExecuted("SEARCH")
            return resp
        }

        if (lower.contains("youtube")) {
            val query = command.substringAfter("youtube", "trending synthwave").trim()
            hardwareController.openYouTubeSearch(query)
            val resp = "Opening YouTube search stream for '$query'."
            saveHistory(command, resp, isVoice)
            onActionExecuted("YOUTUBE")
            return resp
        }

        // 2. Memory Saving Intent ("remember that...")
        if (lower.contains("remember that") || lower.contains("remember my") || lower.contains("my favorite")) {
            val memoryText = command.replace("remember that", "").replace("remember", "").trim()
            val category = when {
                lower.contains("app") -> "App"
                lower.contains("music") || lower.contains("song") -> "Habit"
                lower.contains("friend") || lower.contains("family") || lower.contains("mom") || lower.contains("dad") -> "Family"
                else -> "Personal"
            }
            memoryDao.insertMemory(
                MemoryEntity(
                    category = category,
                    title = "User Preference",
                    content = memoryText.capitalize(),
                    isEncrypted = true
                )
            )
            val resp = "Memory confirmed and encrypted in local XO vault: '$memoryText'."
            saveHistory(command, resp, isVoice)
            onActionExecuted("MEMORY_SAVED")
            return resp
        }

        // 3. Gemini AI Query with Memory Context
        val userMemories = try {
            memoryDao.getAllMemories().firstOrNull()?.take(5)?.joinToString("; ") { "${it.category}: ${it.content}" } ?: ""
        } catch (e: Exception) {
            ""
        }

        val systemPrompt = """
            You are XO AI, a futuristic, fast, hyper-intelligent deep male AI companion with a sleek black & neon green aesthetic.
            Speak in a concise, confident, cybernetic tone. Be helpful, direct, and motivating.
            Stored user context memories: $userMemories
        """.trimIndent()

        val aiResponse = geminiService.generateContent(command, systemPrompt)
        saveHistory(command, aiResponse, isVoice)
        return aiResponse
    }

    private suspend fun saveHistory(command: String, response: String, isVoice: Boolean) {
        try {
            recentCommandDao.insertCommand(
                RecentCommandEntity(
                    commandText = command,
                    responseText = response,
                    isVoice = isVoice
                )
            )
        } catch (e: Exception) {
            // Ignore DB errors
        }
    }
}
