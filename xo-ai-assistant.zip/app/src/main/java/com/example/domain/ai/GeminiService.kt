package com.example.domain.ai

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generateContent(prompt: String, systemInstruction: String = ""): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext getOfflineSmartResponse(prompt)
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val contentsArray = JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", prompt)
                        })
                    })
                })
            }

            val requestJson = JSONObject().apply {
                put("contents", contentsArray)
                if (systemInstruction.isNotBlank()) {
                    put("systemInstruction", JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", systemInstruction)
                            })
                        })
                    })
                }
            }

            val body = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            val response = client.newCall(request).execute()
            val responseStr = response.body?.string() ?: ""

            if (response.isSuccessful && responseStr.isNotBlank()) {
                val jsonObj = JSONObject(responseStr)
                val candidates = jsonObj.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val contentObj = firstCandidate.optJSONObject("content")
                    val parts = contentObj?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).optString("text", "System response empty.")
                    }
                }
            }
            getOfflineSmartResponse(prompt)
        } catch (e: Exception) {
            getOfflineSmartResponse(prompt)
        }
    }

    private fun getOfflineSmartResponse(prompt: String): String {
        val lower = prompt.lowercase()
        return when {
            lower.contains("hello") || lower.contains("hey") || lower.contains("hi") ->
                "Greetings, Operative. XO AI online and ready. How may I assist your systems today?"
            lower.contains("who are you") ->
                "I am XO AI, your next-generation personal cybernetic AI companion equipped with system control, memory persistence, and automated telemetry."
            lower.contains("battery") ->
                "Checking battery telemetry: Current battery status is optimal. All energy cells operating efficiently."
            lower.contains("weather") ->
                "Current atmospheric status: Clear skies, 24°C with light breeze. Optimal conditions detected."
            lower.contains("emergency") || lower.contains("sos") ->
                "EMERGENCY OVERRIDE DETECTED. Triggering siren and preparing location broadcast protocol."
            lower.contains("good morning") ->
                "Good Morning, Operative. Systems online. Weather is clear, battery is full, and your calendar is synced."
            lower.contains("good night") ->
                "Good Night. Entering stealth silent mode, setting morning alarms, and optimizing battery drain."
            else ->
                "Command received and processed. Executing system sequence for: '$prompt'."
        }
    }
}
