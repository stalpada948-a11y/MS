package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.XOTab
import com.example.ui.components.FloatingStartPanel
import com.example.ui.components.XOGlowingOrb
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Permissions handled gracefully
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Request runtime permissions if needed
        val permissionsToRequest = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            permissionsToRequest.add(Manifest.permission.RECORD_AUDIO)
        }
        if (permissionsToRequest.isNotEmpty()) {
            requestPermissionLauncher.launch(permissionsToRequest.toTypedArray())
        }

        setContent {
            MyApplicationTheme(darkTheme = true) {
                XOAppRoot()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun XOAppRoot(viewModel: MainViewModel = viewModel()) {
    val currentTab by viewModel.currentTab.collectAsState()
    val orbState by viewModel.orbState.collectAsState()
    val isStartPanelOpen by viewModel.isStartPanelOpen.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val systemStats by viewModel.systemStats.collectAsState()
    val memories by viewModel.memories.collectAsState()
    val automations by viewModel.automations.collectAsState()
    val recentCommands by viewModel.recentCommands.collectAsState()
    val userNotes by viewModel.userNotes.collectAsState()
    val isFlashlightOn by viewModel.hardwareController.isFlashlightOn.collectAsState()
    val isListening by viewModel.speechManager?.isListening?.collectAsState() ?: remember { mutableStateOf(false) }

    val voicePitch by viewModel.voicePitch.collectAsState()
    val voiceSpeed by viewModel.voiceSpeed.collectAsState()
    val wakeWordEnabled by viewModel.wakeWordEnabled.collectAsState()
    val floatingOrbEnabled by viewModel.floatingOrbEnabled.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = XOBlack,
        bottomBar = {
            NavigationBar(
                containerColor = XODarkObsidian,
                contentColor = XONeonGreen,
                windowInsets = WindowInsets.navigationBars,
                modifier = Modifier
                    .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                    .border(1.dp, XOCardBorder, RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            ) {
                NavigationBarItem(
                    selected = currentTab == XOTab.HOME,
                    onClick = { viewModel.selectTab(XOTab.HOME) },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = XOBlack,
                        selectedTextColor = XONeonGreen,
                        indicatorColor = XONeonGreen,
                        unselectedIconColor = XOTextSecondary,
                        unselectedTextColor = XOTextMuted
                    )
                )

                NavigationBarItem(
                    selected = currentTab == XOTab.CHAT,
                    onClick = { viewModel.selectTab(XOTab.CHAT) },
                    icon = { Icon(Icons.Default.Chat, contentDescription = "AI Chat") },
                    label = { Text("Chat", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = XOBlack,
                        selectedTextColor = XOCyberCyan,
                        indicatorColor = XOCyberCyan,
                        unselectedIconColor = XOTextSecondary,
                        unselectedTextColor = XOTextMuted
                    )
                )

                NavigationBarItem(
                    selected = currentTab == XOTab.MEMORY,
                    onClick = { viewModel.selectTab(XOTab.MEMORY) },
                    icon = { Icon(Icons.Default.Psychology, contentDescription = "Memory") },
                    label = { Text("Memory", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = XOBlack,
                        selectedTextColor = XOCyberPurple,
                        indicatorColor = XOCyberPurple,
                        unselectedIconColor = XOTextSecondary,
                        unselectedTextColor = XOTextMuted
                    )
                )

                NavigationBarItem(
                    selected = currentTab == XOTab.AUTOMATION,
                    onClick = { viewModel.selectTab(XOTab.AUTOMATION) },
                    icon = { Icon(Icons.Default.AutoMode, contentDescription = "Automation") },
                    label = { Text("Routine", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = XOBlack,
                        selectedTextColor = XOWarningGold,
                        indicatorColor = XOWarningGold,
                        unselectedIconColor = XOTextSecondary,
                        unselectedTextColor = XOTextMuted
                    )
                )

                NavigationBarItem(
                    selected = currentTab == XOTab.DASHBOARD,
                    onClick = { viewModel.selectTab(XOTab.DASHBOARD) },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                    label = { Text("Stats", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = XOBlack,
                        selectedTextColor = XONeonGreen,
                        indicatorColor = XONeonGreen,
                        unselectedIconColor = XOTextSecondary,
                        unselectedTextColor = XOTextMuted
                    )
                )

                NavigationBarItem(
                    selected = currentTab == XOTab.EMERGENCY,
                    onClick = { viewModel.selectTab(XOTab.EMERGENCY) },
                    icon = { Icon(Icons.Default.Warning, contentDescription = "Emergency") },
                    label = { Text("SOS", fontSize = 10.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = XOBlack,
                        selectedTextColor = XOEmergencyRed,
                        indicatorColor = XOEmergencyRed,
                        unselectedIconColor = XOTextSecondary,
                        unselectedTextColor = XOTextMuted
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Main Active Screen Switcher
            when (currentTab) {
                XOTab.HOME -> HomeScreen(
                    orbState = orbState,
                    systemStats = systemStats,
                    recentCommands = recentCommands,
                    onMicClick = {
                        if (isListening) viewModel.stopVoiceListening() else viewModel.startVoiceListening()
                    },
                    onOpenStartPanel = { viewModel.toggleStartPanel() },
                    onQuickAction = { action -> viewModel.processUserCommand(action, isVoice = false) },
                    onNavigateTab = { tab -> viewModel.selectTab(tab) }
                )

                XOTab.CHAT -> AIChatScreen(
                    messages = chatMessages,
                    onSendMessage = { msg -> viewModel.processUserCommand(msg, isVoice = false) },
                    onMicClick = {
                        if (isListening) viewModel.stopVoiceListening() else viewModel.startVoiceListening()
                    },
                    isListening = isListening
                )

                XOTab.VOICE -> AIChatScreen(
                    messages = chatMessages,
                    onSendMessage = { msg -> viewModel.processUserCommand(msg, isVoice = true) },
                    onMicClick = {
                        if (isListening) viewModel.stopVoiceListening() else viewModel.startVoiceListening()
                    },
                    isListening = isListening
                )

                XOTab.MEMORY -> MemoryScreen(
                    memories = memories,
                    onAddMemory = { cat, title, content -> viewModel.addMemory(cat, title, content) },
                    onDeleteMemory = { mem -> viewModel.deleteMemory(mem) },
                    onClearAll = { viewModel.clearAllMemories() }
                )

                XOTab.AUTOMATION -> AutomationScreen(
                    automations = automations,
                    onToggleAutomation = { auto -> viewModel.toggleAutomation(auto) },
                    onRunRoutine = { trigger -> viewModel.processUserCommand(trigger, isVoice = false) }
                )

                XOTab.DASHBOARD -> DashboardScreen(
                    systemStats = systemStats,
                    isFlashlightOn = isFlashlightOn,
                    onToggleFlashlight = { viewModel.hardwareController.toggleFlashlight() }
                )

                XOTab.NOTES -> NotesScreen(
                    notes = userNotes,
                    onAddNote = { note -> viewModel.addNote(note) }
                )

                XOTab.SETTINGS -> SettingsScreen(
                    voicePitch = voicePitch,
                    voiceSpeed = voiceSpeed,
                    wakeWordEnabled = wakeWordEnabled,
                    floatingOrbEnabled = floatingOrbEnabled,
                    onVoicePitchChanged = { pitch ->
                        viewModel.voicePitch.value = pitch
                        viewModel.speechManager?.setDeepVoiceParameters(pitch, voiceSpeed)
                    },
                    onVoiceSpeedChanged = { speed ->
                        viewModel.voiceSpeed.value = speed
                        viewModel.speechManager?.setDeepVoiceParameters(voicePitch, speed)
                    },
                    onWakeWordToggled = { enabled -> viewModel.wakeWordEnabled.value = enabled },
                    onFloatingOrbToggled = { enabled -> viewModel.floatingOrbEnabled.value = enabled },
                    onClearMemories = { viewModel.clearAllMemories() }
                )

                XOTab.EMERGENCY -> EmergencyScreen(
                    onTriggerEmergency = { viewModel.triggerEmergency() },
                    onCallEmergency = { viewModel.hardwareController.dialPhone("911") },
                    onToggleFlashlight = { viewModel.hardwareController.toggleFlashlight() }
                )
            }

            // Quick Floating Dock Orb (Corner overlay on non-home screens if enabled)
            if (currentTab != XOTab.HOME && floatingOrbEnabled) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(bottom = 12.dp, end = 12.dp)
                ) {
                    XOGlowingOrb(
                        orbState = orbState,
                        onSingleTap = { viewModel.toggleStartPanel() },
                        onDoubleTap = {
                            if (isListening) viewModel.stopVoiceListening() else viewModel.startVoiceListening()
                        },
                        onLongPress = { viewModel.selectTab(XOTab.HOME) }
                    )
                }
            }

            // Quick Floating Start Panel Sheet Overlay
            FloatingStartPanel(
                isOpen = isStartPanelOpen,
                onClose = { viewModel.toggleStartPanel() },
                onSelectTab = { tab -> viewModel.selectTab(tab) },
                onQuickAction = { action ->
                    viewModel.toggleStartPanel()
                    viewModel.processUserCommand(action, isVoice = false)
                }
            )
        }
    }
}

