package com.example.util

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast

object SystemControlHelper {

    fun setVolume(context: Context, percent: Int): String {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (audioManager != null) {
            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val newVolume = (maxVolume * (percent.coerceIn(0, 100) / 100f)).toInt()
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVolume, AudioManager.FLAG_SHOW_UI)
            return "Media volume set to $percent%"
        }
        return "Unable to access AudioManager"
    }

    fun openAppByName(context: Context, queryName: String): String {
        val q = queryName.lowercase().trim()
        val pm = context.packageManager

        // Known direct launcher intents for common apps
        val knownPackage = when {
            q.contains("youtube") -> "com.google.android.youtube"
            q.contains("whatsapp") -> "com.whatsapp"
            q.contains("spotify") -> "com.spotify.music"
            q.contains("chrome") -> "com.android.chrome"
            q.contains("instagram") -> "com.instagram.android"
            q.contains("telegram") -> "org.telegram.messenger"
            q.contains("maps") -> "com.google.android.apps.maps"
            q.contains("gmail") -> "com.google.android.gm"
            else -> null
        }

        if (knownPackage != null) {
            val intent = pm.getLaunchIntentForPackage(knownPackage)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return "Launching $queryName..."
            }
        }

        if (q.contains("camera")) {
            val cameraIntent = Intent(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(cameraIntent)
                return "Opening Camera..."
            } catch (_: Exception) {}
        }

        if (q.contains("setting") || q.contains("settings")) {
            val settingsIntent = Intent(Settings.ACTION_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(settingsIntent)
                return "Opening Android Settings..."
            } catch (_: Exception) {}
        }

        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val apps = pm.queryIntentActivities(mainIntent, 0)
        
        val matchedApp = apps.firstOrNull {
            val label = it.loadLabel(pm).toString()
            label.contains(queryName, ignoreCase = true) || it.activityInfo.packageName.contains(queryName, ignoreCase = true)
        }

        if (matchedApp != null) {
            val launchIntent = pm.getLaunchIntentForPackage(matchedApp.activityInfo.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                return "Launching ${matchedApp.loadLabel(pm)}..."
            }
        }
        return "Application matching '$queryName' was not found on device."
    }

    fun toggleWifi(context: Context, enable: Boolean): String {
        val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return "Opening Wi-Fi controls to ${if (enable) "enable" else "disable"} Wi-Fi."
    }

    fun toggleBluetooth(context: Context, enable: Boolean): String {
        val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        return "Opening Bluetooth settings to adjust connection."
    }

    fun openSettingsScreen(context: Context, action: String) {
        val intent = Intent(action).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "Cannot open settings page directly", Toast.LENGTH_SHORT).show()
        }
    }

    fun requestOverlayPermission(context: Context) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        }
    }
}
