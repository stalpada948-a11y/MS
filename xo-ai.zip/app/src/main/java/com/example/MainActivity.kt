package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.ai.GeminiManager
import com.example.data.XoPreferences
import com.example.data.db.AppDatabase
import com.example.services.SpeechManager
import com.example.services.XoForegroundService
import com.example.ui.MainScreen
import com.example.ui.OnboardingFlow
import com.example.ui.SplashLoadingScreen
import com.example.ui.theme.XoAiTheme

enum class AppScreenState {
    SPLASH,
    ONBOARDING,
    MAIN
}

class MainActivity : ComponentActivity() {

    private lateinit var prefs: XoPreferences
    private lateinit var database: AppDatabase
    private lateinit var geminiManager: GeminiManager
    private lateinit var speechManager: SpeechManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        prefs = XoPreferences(this)
        database = AppDatabase.getDatabase(this)
        geminiManager = GeminiManager(this, prefs)
        speechManager = SpeechManager(this)

        if (prefs.isOnboardingCompleted) {
            XoForegroundService.startService(this)
        }

        setContent {
            var screenState by remember { mutableStateOf(AppScreenState.SPLASH) }

            XoAiTheme(darkTheme = prefs.isDarkMode) {
                when (screenState) {
                    AppScreenState.SPLASH -> {
                        SplashLoadingScreen(
                            onFinished = {
                                screenState = if (prefs.isOnboardingCompleted) {
                                    AppScreenState.MAIN
                                } else {
                                    AppScreenState.ONBOARDING
                                }
                            }
                        )
                    }

                    AppScreenState.ONBOARDING -> {
                        OnboardingFlow(
                            prefs = prefs,
                            speechManager = speechManager,
                            onComplete = {
                                XoForegroundService.startService(this@MainActivity)
                                screenState = AppScreenState.MAIN
                            }
                        )
                    }

                    AppScreenState.MAIN -> {
                        MainScreen(
                            database = database,
                            geminiManager = geminiManager,
                            speechManager = speechManager,
                            prefs = prefs,
                            onResetOnboarding = {
                                prefs.isOnboardingCompleted = false
                                screenState = AppScreenState.ONBOARDING
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::speechManager.isInitialized) {
            speechManager.shutdown()
        }
    }
}
