package com.example.services

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.data.XoPreferences

class XoBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            val prefs = XoPreferences(context)
            if (prefs.isOnboardingCompleted) {
                XoForegroundService.startService(context)
            }
        }
    }
}
