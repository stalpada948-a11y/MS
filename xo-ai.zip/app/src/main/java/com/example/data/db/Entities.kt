package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String, // "user" or "xo"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isVoice: Boolean = false,
    val actionExecuted: String? = null
)

@Entity(tableName = "automation_tasks")
data class AutomationTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val type: String, // "alarm", "reminder", "note", "system_action", "network_scan"
    val details: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isCompleted: Boolean = false
)

@Entity(tableName = "network_devices")
data class NetworkDeviceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val ipAddress: String,
    val deviceName: String,
    val macAddress: String = "N/A",
    val latencyMs: Long = 0,
    val isOnline: Boolean = true,
    val lastSeen: Long = System.currentTimeMillis()
)
