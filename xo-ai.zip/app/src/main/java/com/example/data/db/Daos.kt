package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Query("DELETE FROM chat_messages")
    suspend fun clearHistory()
}

@Dao
interface AutomationTaskDao {
    @Query("SELECT * FROM automation_tasks ORDER BY timestamp DESC")
    fun getAllTasks(): Flow<List<AutomationTaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: AutomationTaskEntity): Long

    @Query("UPDATE automation_tasks SET isCompleted = :completed WHERE id = :id")
    suspend fun updateTaskStatus(id: Long, completed: Boolean)

    @Query("DELETE FROM automation_tasks WHERE id = :id")
    suspend fun deleteTask(id: Long)
}

@Dao
interface NetworkDeviceDao {
    @Query("SELECT * FROM network_devices ORDER BY ipAddress ASC")
    fun getAllDevices(): Flow<List<NetworkDeviceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDevices(devices: List<NetworkDeviceEntity>)

    @Query("DELETE FROM network_devices")
    suspend fun clearDevices()
}
