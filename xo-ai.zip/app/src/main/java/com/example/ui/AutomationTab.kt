package com.example.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.db.AutomationTaskDao
import com.example.data.db.AutomationTaskEntity
import com.example.ui.theme.DarkGlass
import com.example.ui.theme.DarkGlassBorder
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.PureBlack
import com.example.util.SystemControlHelper
import com.example.util.XoAccessibilityService
import kotlinx.coroutines.launch

@Composable
fun AutomationTab(
    automationTaskDao: AutomationTaskDao
) {
    val context = LocalContext.current
    val tasks by automationTaskDao.getAllTasks().collectAsState(initial = emptyList())
    val coroutineScope = rememberCoroutineScope()

    var volumePercent by remember { mutableFloatStateOf(70f) }
    var appToLaunch by remember { mutableStateOf("") }
    var taskTitle by remember { mutableStateOf("") }
    var taskDetails by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(16.dp)
            .testTag("automation_tab_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "System Control & Automation",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Execute hands-free hardware actions and schedule automated tasks.",
                color = Color.Gray,
                fontSize = 12.sp
            )
        }

        // Quick Gesture Shortcuts Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGlass),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "⚡ Accessibility Gestures",
                        color = NeonGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        GestureButton("Home", Icons.Default.Home) {
                            XoAccessibilityService.navigateHome()
                        }
                        GestureButton("Notifications", Icons.Default.Notifications) {
                            XoAccessibilityService.openNotifications()
                        }
                        GestureButton("Back", Icons.Default.Apps) {
                            XoAccessibilityService.navigateBack()
                        }
                    }
                }
            }
        }

        // Volume & Network Hardware Toggles
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGlass),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null, tint = NeonGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Media Volume: ${volumePercent.toInt()}%",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Slider(
                        value = volumePercent,
                        onValueChange = {
                            volumePercent = it
                            SystemControlHelper.setVolume(context, it.toInt())
                        },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(thumbColor = NeonGreen, activeTrackColor = NeonGreen)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { SystemControlHelper.toggleWifi(context, true) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16291E)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkGlassBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.Wifi, contentDescription = null, tint = NeonGreen)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Wi-Fi Settings", color = Color.White, fontSize = 11.sp)
                        }

                        Button(
                            onClick = { SystemControlHelper.toggleBluetooth(context, true) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16291E)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, DarkGlassBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.Bluetooth, contentDescription = null, tint = NeonGreen)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Bluetooth", color = Color.White, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Open Application Launcher
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGlass),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "🚀 App Launcher Automation", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = appToLaunch,
                            onValueChange = { appToLaunch = it },
                            placeholder = { Text("App name (e.g. Chrome, Camera)...") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonGreen,
                                unfocusedBorderColor = DarkGlassBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                if (appToLaunch.isNotBlank()) {
                                    SystemControlHelper.openAppByName(context, appToLaunch)
                                    appToLaunch = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen)
                        ) {
                            Text("LAUNCH", color = PureBlack, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Create Task / Reminder Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGlass),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "⏰ Schedule Reminder / Task", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = taskTitle,
                        onValueChange = { taskTitle = it },
                        label = { Text("Task / Reminder Title") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonGreen,
                            unfocusedBorderColor = DarkGlassBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = taskDetails,
                        onValueChange = { taskDetails = it },
                        label = { Text("Details (e.g. 15 minutes)") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonGreen,
                            unfocusedBorderColor = DarkGlassBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            if (taskTitle.isNotBlank()) {
                                coroutineScope.launch {
                                    automationTaskDao.insertTask(
                                        AutomationTaskEntity(
                                            title = taskTitle,
                                            type = "Reminder",
                                            details = taskDetails.ifBlank { "Scheduled task" }
                                        )
                                    )
                                    taskTitle = ""
                                    taskDetails = ""
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = PureBlack)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("ADD AUTOMATION TASK", color = PureBlack, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Active Tasks List Header
        item {
            Text(
                text = "Active Automation Tasks (${tasks.size})",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        }

        items(tasks) { task ->
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGlass),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = task.title,
                            color = if (task.isCompleted) Color.Gray else Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = task.details,
                            color = Color.Gray,
                            fontSize = 12.sp
                        )
                    }

                    Checkbox(
                        checked = task.isCompleted,
                        onCheckedChange = { checked ->
                            coroutineScope.launch {
                                automationTaskDao.updateTaskStatus(task.id, checked)
                            }
                        },
                        colors = CheckboxDefaults.colors(
                            checkedColor = NeonGreen,
                            checkmarkColor = PureBlack
                        )
                    )
                }
            }
        }
    }
}

@Composable
private fun GestureButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF16241C))
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = NeonGreen)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}
