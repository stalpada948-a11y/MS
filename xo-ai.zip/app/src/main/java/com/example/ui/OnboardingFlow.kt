package com.example.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.XoPreferences
import com.example.services.SpeechManager
import com.example.ui.theme.DarkGlass
import com.example.ui.theme.DarkGlassBorder
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.PureBlack
import com.example.util.ShizukuHelper
import com.example.util.SystemControlHelper
import com.example.util.XoAccessibilityService

@Composable
fun OnboardingFlow(
    prefs: XoPreferences,
    speechManager: SpeechManager,
    onComplete: () -> Unit
) {
    val context = LocalContext.current
    var currentStep by remember { mutableIntStateOf(1) }

    // Form state
    var apiKey by remember { mutableStateOf(prefs.apiKey) }
    var isApiKeyVisible by remember { mutableStateOf(false) }
    var wakeWordEnabled by remember { mutableStateOf(prefs.wakeWordEnabled) }
    var wakePhrase by remember { mutableStateOf(prefs.wakePhrase) }
    var voicePitch by remember { mutableFloatStateOf(prefs.voicePitch) }
    var voiceSpeed by remember { mutableFloatStateOf(prefs.voiceSpeed) }
    var isDarkMode by remember { mutableStateOf(prefs.isDarkMode) }

    // Permission check state
    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(24.dp)
            .testTag("onboarding_flow")
    ) {
        // Header Progress Indicator
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, bottom = 24.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            if (currentStep > 1) {
                IconButton(
                    onClick = { currentStep-- },
                    modifier = Modifier.testTag("onboarding_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }
            } else {
                Spacer(modifier = Modifier.size(48.dp))
            }

            Text(
                text = "STEP $currentStep OF 6",
                color = NeonGreen,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.size(48.dp))
        }

        // Progress Dots
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            for (step in 1..6) {
                Box(
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .size(height = 6.dp, width = if (step == currentStep) 24.dp else 8.dp)
                        .clip(CircleShape)
                        .background(if (step == currentStep) NeonGreen else Color(0xFF26332C))
                )
            }
        }

        // Main Step Content Container
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            AnimatedContent(
                targetState = currentStep,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "onboarding_step"
            ) { step ->
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.Top
                ) {
                    when (step) {
                        1 -> StepGeminiKey(
                            apiKey = apiKey,
                            isApiKeyVisible = isApiKeyVisible,
                            onApiKeyChange = { apiKey = it },
                            onToggleVisibility = { isApiKeyVisible = !isApiKeyVisible }
                        )

                        2 -> StepWakeWord(
                            wakeWordEnabled = wakeWordEnabled,
                            wakePhrase = wakePhrase,
                            onEnabledChange = { wakeWordEnabled = it },
                            onPhraseChange = { wakePhrase = it }
                        )

                        3 -> StepVoiceEngine(
                            pitch = voicePitch,
                            speed = voiceSpeed,
                            onPitchChange = { voicePitch = it },
                            onSpeedChange = { voiceSpeed = it },
                            onTestSpeech = {
                                speechManager.speak(
                                    "Hello! I am XO AI, your intelligent voice assistant.",
                                    pitch = voicePitch,
                                    rate = voiceSpeed
                                )
                            }
                        )

                        4 -> StepThemeSelection(
                            isDarkMode = isDarkMode,
                            onThemeSelected = { isDarkMode = it }
                        )

                        5 -> StepPermissions(
                            context = context,
                            hasMicPermission = hasMicPermission,
                            onRequestMic = { micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                        )

                        6 -> StepCompletion()
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Next / Finish Action Button
        Button(
            onClick = {
                // Save progress
                prefs.apiKey = apiKey
                prefs.wakeWordEnabled = wakeWordEnabled
                prefs.wakePhrase = wakePhrase
                prefs.voicePitch = voicePitch
                prefs.voiceSpeed = voiceSpeed
                prefs.isDarkMode = isDarkMode

                if (currentStep < 6) {
                    currentStep++
                } else {
                    prefs.isOnboardingCompleted = true
                    onComplete()
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = NeonGreen,
                contentColor = PureBlack
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("onboarding_next_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = if (currentStep == 6) "LAUNCH XO AI OVERLAY" else "CONTINUE",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = if (currentStep == 6) Icons.Default.Check else Icons.Default.ArrowForward,
                    contentDescription = null
                )
            }
        }
    }
}

@Composable
private fun StepGeminiKey(
    apiKey: String,
    isApiKeyVisible: Boolean,
    onApiKeyChange: (String) -> Unit,
    onToggleVisibility: () -> Unit
) {
    Column {
        Icon(
            imageVector = Icons.Default.Key,
            contentDescription = null,
            tint = NeonGreen,
            modifier = Modifier.size(48.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Gemini API Key Setup",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Enter your Google Gemini API Key to enable advanced personal intelligence and real-time voice processing.",
            color = Color(0xFFA0B0A8),
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(28.dp))

        OutlinedTextField(
            value = apiKey,
            onValueChange = onApiKeyChange,
            label = { Text("Gemini API Key") },
            placeholder = { Text("AIzaSy...") },
            singleLine = true,
            visualTransformation = if (isApiKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                Text(
                    text = if (isApiKeyVisible) "HIDE" else "SHOW",
                    color = NeonGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .clickable { onToggleVisibility() }
                        .padding(8.dp)
                )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonGreen,
                unfocusedBorderColor = DarkGlassBorder,
                focusedLabelColor = NeonGreen,
                unfocusedLabelColor = Color.Gray,
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("api_key_input")
        )

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = DarkGlass),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "🔒 Security Guarantee",
                    color = NeonGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Your API key is stored locally on device using Android Sandboxed Preferences. It is never uploaded to third-party servers.",
                    color = Color.LightGray,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
private fun StepWakeWord(
    wakeWordEnabled: Boolean,
    wakePhrase: String,
    onEnabledChange: (Boolean) -> Unit,
    onPhraseChange: (String) -> Unit
) {
    Column {
        Icon(
            imageVector = Icons.Default.Mic,
            contentDescription = null,
            tint = NeonGreen,
            modifier = Modifier.size(48.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Wake Word Configuration",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Configure hands-free voice activation so XO AI wakes up automatically when called.",
            color = Color(0xFFA0B0A8),
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(28.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = DarkGlass),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Enable Wake Word Detection",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "Allows XO AI to listen for the hotword anytime.",
                        color = Color.Gray,
                        fontSize = 12.sp
                    )
                }

                Switch(
                    checked = wakeWordEnabled,
                    onCheckedChange = onEnabledChange,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = PureBlack,
                        checkedTrackColor = NeonGreen
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (wakeWordEnabled) {
            OutlinedTextField(
                value = wakePhrase,
                onValueChange = onPhraseChange,
                label = { Text("Wake Phrase") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonGreen,
                    unfocusedBorderColor = DarkGlassBorder,
                    focusedLabelColor = NeonGreen,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun StepVoiceEngine(
    pitch: Float,
    speed: Float,
    onPitchChange: (Float) -> Unit,
    onSpeedChange: (Float) -> Unit,
    onTestSpeech: () -> Unit
) {
    Column {
        Icon(
            imageVector = Icons.Default.VolumeUp,
            contentDescription = null,
            tint = NeonGreen,
            modifier = Modifier.size(48.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Voice Synthesis Engine",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Customize the pitch and speed of XO AI's speech synthesis response engine.",
            color = Color(0xFFA0B0A8),
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(28.dp))

        Text(
            text = "Voice Pitch: ${String.format("%.2f", pitch)}x",
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        Slider(
            value = pitch,
            onValueChange = onPitchChange,
            valueRange = 0.5f..1.5f,
            colors = SliderDefaults.colors(
                thumbColor = NeonGreen,
                activeTrackColor = NeonGreen
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Voice Speed: ${String.format("%.2f", speed)}x",
            color = Color.White,
            fontWeight = FontWeight.Bold
        )
        Slider(
            value = speed,
            onValueChange = onSpeedChange,
            valueRange = 0.5f..1.5f,
            colors = SliderDefaults.colors(
                thumbColor = NeonGreen,
                activeTrackColor = NeonGreen
            )
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onTestSpeech,
            colors = ButtonDefaults.buttonColors(containerColor = DarkGlass),
            border = androidx.compose.foundation.BorderStroke(1.dp, NeonGreen),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("TEST SPEECH SYNTHESIS", color = NeonGreen, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun StepThemeSelection(
    isDarkMode: Boolean,
    onThemeSelected: (Boolean) -> Unit
) {
    Column {
        Icon(
            imageVector = Icons.Default.Palette,
            contentDescription = null,
            tint = NeonGreen,
            modifier = Modifier.size(48.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Theme Customization",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Choose your visual theme preference. Premium Dark Mode with Pure Black background and Neon accents is recommended.",
            color = Color(0xFFA0B0A8),
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(28.dp))

        Row(modifier = Modifier.fillMaxWidth()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = if (isDarkMode) Color(0xFF141F1A) else DarkGlass),
                border = androidx.compose.foundation.BorderStroke(2.dp, if (isDarkMode) NeonGreen else Color.Transparent),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onThemeSelected(true) }
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("🌙", fontSize = 32.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Premium Dark", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Pure Black & Neon", color = NeonGreen, fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.width(16.dp))

            Card(
                colors = CardDefaults.cardColors(containerColor = if (!isDarkMode) Color(0xFF202A24) else DarkGlass),
                border = androidx.compose.foundation.BorderStroke(2.dp, if (!isDarkMode) NeonGreen else Color.Transparent),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onThemeSelected(false) }
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("☀️", fontSize = 32.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Light Mode", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Clean High Contrast", color = Color.LightGray, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun StepPermissions(
    context: Context,
    hasMicPermission: Boolean,
    onRequestMic: () -> Unit
) {
    Column {
        Icon(
            imageVector = Icons.Default.Security,
            contentDescription = null,
            tint = NeonGreen,
            modifier = Modifier.size(48.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "System Permissions",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "Grant necessary system permissions to enable floating overlay and hands-free voice automation.",
            color = Color(0xFFA0B0A8),
            fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Microphone Card
        PermissionCard(
            title = "Microphone Access",
            description = "Required for speech-to-text recognition and wake word detection.",
            isGranted = hasMicPermission,
            onAction = onRequestMic
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Overlay Card
        PermissionCard(
            title = "System Overlay Window",
            description = "Allows XO AI floating orb to display over active applications.",
            isGranted = android.provider.Settings.canDrawOverlays(context),
            onAction = { SystemControlHelper.requestOverlayPermission(context) }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Accessibility Service Card
        PermissionCard(
            title = "Accessibility Service",
            description = "Enables hands-free system gestures (Home, Back, Screenshot).",
            isGranted = XoAccessibilityService.isServiceActive,
            onAction = { SystemControlHelper.openSettingsScreen(context, android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS) }
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Shizuku Status Card
        PermissionCard(
            title = "Shizuku Integration",
            description = ShizukuHelper.getStatusDescription(context),
            isGranted = false,
            onAction = {}
        )
    }
}

@Composable
private fun PermissionCard(
    title: String,
    description: String,
    isGranted: Boolean,
    onAction: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = DarkGlass),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isGranted) NeonGreen else DarkGlassBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(text = description, color = Color.Gray, fontSize = 11.sp)
            }

            Spacer(modifier = Modifier.width(8.dp))

            if (isGranted) {
                Text(
                    text = "ACTIVE",
                    color = NeonGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF122E1F))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                )
            } else {
                Button(
                    onClick = onAction,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22332A)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("GRANT", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun StepCompletion() {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
    ) {
        Spacer(modifier = Modifier.height(24.dp))
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(Color(0xFF142C20))
                .border(2.dp, NeonGreen, CircleShape)
        ) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = NeonGreen,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "XO AI Initialized!",
            color = Color.White,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Your Intelligent Personal AI Companion is ready. The background service and floating dynamic overlay are prepared for operation.",
            color = Color(0xFFA0B0A8),
            fontSize = 14.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(32.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = DarkGlass),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "⚡ Quick Voice Commands:", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "• \"Hey XO, scan local network\"", color = Color.White, fontSize = 13.sp)
                Text(text = "• \"Hey XO, check network status\"", color = Color.White, fontSize = 13.sp)
                Text(text = "• \"Hey XO, open camera\"", color = Color.White, fontSize = 13.sp)
                Text(text = "• \"Hey XO, turn volume to 80%\"", color = Color.White, fontSize = 13.sp)
            }
        }
    }
}
