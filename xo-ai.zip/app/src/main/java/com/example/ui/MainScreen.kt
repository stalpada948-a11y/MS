package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.GeminiManager
import com.example.data.XoPreferences
import com.example.data.db.AppDatabase
import com.example.services.SpeechManager
import com.example.ui.theme.DarkGlass
import com.example.ui.theme.DarkGlassBorder
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.PureBlack

sealed class MainTab(val title: String, val icon: ImageVector) {
    object Chat : MainTab("AI Chat", Icons.Default.Chat)
    object Automation : MainTab("Automation", Icons.Default.AutoMode)
    object Network : MainTab("Network", Icons.Default.Lan)
    object Settings : MainTab("Settings", Icons.Default.Settings)
}

@Composable
fun MainScreen(
    database: AppDatabase,
    geminiManager: GeminiManager,
    speechManager: SpeechManager,
    prefs: XoPreferences,
    onResetOnboarding: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }

    val tabs = listOf(
        MainTab.Chat,
        MainTab.Automation,
        MainTab.Network,
        MainTab.Settings
    )

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = DarkGlass,
                contentColor = NeonGreen,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .navigationBarsPadding()
                    .testTag("main_bottom_navigation")
            ) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PureBlack,
                            selectedTextColor = NeonGreen,
                            indicatorColor = NeonGreen,
                            unselectedIconColor = Color.Gray,
                            unselectedTextColor = Color.Gray
                        ),
                        modifier = Modifier.testTag("nav_item_${tab.title.lowercase()}")
                    )
                }
            }
        },
        containerColor = PureBlack,
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(PureBlack)
        ) {
            // Top MAX Style Floating XO Pill Overlay
            FloatingOverlayView(
                speechManager = speechManager,
                onTap = {
                    speechManager.startListening()
                    selectedTab = 0 // jump to chat
                },
                onExpandChat = {
                    selectedTab = 0
                }
            )

            // Tab Content
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxSize()
            ) {
                when (selectedTab) {
                    0 -> ChatTab(
                        chatMessageDao = database.chatMessageDao(),
                        geminiManager = geminiManager,
                        speechManager = speechManager
                    )

                    1 -> AutomationTab(
                        automationTaskDao = database.automationTaskDao()
                    )

                    2 -> NetworkTab()

                    3 -> SettingsTab(
                        prefs = prefs,
                        speechManager = speechManager,
                        onResetOnboarding = onResetOnboarding
                    )
                }
            }
        }
    }
}
