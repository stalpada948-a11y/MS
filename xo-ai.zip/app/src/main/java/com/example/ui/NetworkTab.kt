package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkGlass
import com.example.ui.theme.DarkGlassBorder
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.PureBlack
import com.example.util.NetworkStatusInfo
import com.example.util.NetworkTools
import com.example.util.PortStatus
import kotlinx.coroutines.launch

@Composable
fun NetworkTab() {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var statusInfo by remember { mutableStateOf<NetworkStatusInfo?>(null) }
    var subnetDevices by remember { mutableStateOf<List<Map<String, Any>>>(emptyList()) }
    var portDiagnostics by remember { mutableStateOf<List<PortStatus>>(emptyList()) }

    var isScanningSubnet by remember { mutableStateOf(false) }
    var isCheckingPort by remember { mutableStateOf(false) }

    // Initial check
    LaunchedEffect(Unit) {
        statusInfo = NetworkTools.checkNetworkStatus(context)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(16.dp)
            .testTag("network_tab_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Network Utilities & Diagnostics",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Voice-activated local Wi-Fi subnet discovery, latency ping tests, and port diagnostics.",
                color = Color.Gray,
                fontSize = 12.sp
            )
        }

        // Live Network Status Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGlass),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Router, contentDescription = null, tint = NeonGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Network Connection Status", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    statusInfo = NetworkTools.checkNetworkStatus(context)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B2E24))
                        ) {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh", tint = NeonGreen)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    statusInfo?.let { s ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            StatusMetric("Connection", s.connectionType, NeonGreen)
                            StatusMetric("Latency Ping", "${s.pingMs} ms", CyberCyan)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            StatusMetric("Local IP", s.localIp, Color.White)
                            StatusMetric("Gateway IP", s.gatewayIp, Color.White)
                        }
                    } ?: CircularProgressIndicator(color = NeonGreen, modifier = Modifier.padding(16.dp))
                }
            }
        }

        // Subnet Scanner Action Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGlass),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Lan, contentDescription = null, tint = NeonGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Local Wi-Fi Subnet Discovery", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Scans active IP addresses on your local network.", color = Color.Gray, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            isScanningSubnet = true
                            coroutineScope.launch {
                                subnetDevices = NetworkTools.scanLocalSubnet(context)
                                isScanningSubnet = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isScanningSubnet) {
                            CircularProgressIndicator(color = PureBlack, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("SCANNING SUBNET...", color = PureBlack, fontWeight = FontWeight.Bold)
                        } else {
                            Text("SCAN LOCAL NETWORK", color = PureBlack, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Discovered Devices Header
        if (subnetDevices.isNotEmpty()) {
            item {
                Text(
                    text = "Discovered Network Devices (${subnetDevices.size})",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }

            items(subnetDevices) { dev ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkGlass),
                    border = androidx.compose.foundation.BorderStroke(1.dp, DarkGlassBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(imageVector = Icons.Default.Computer, contentDescription = null, tint = NeonGreen)
                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = dev["ip"].toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(text = dev["name"].toString(), color = Color.Gray, fontSize = 12.sp)
                        }

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF142B20))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = "${dev["latency"]}ms", color = NeonGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Port Scanner Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGlass),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = NeonGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Run Port Diagnostic", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Tests local host sockets for active service ports (HTTP, SSH, DNS, FTP, etc.).", color = Color.Gray, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            isCheckingPort = true
                            coroutineScope.launch {
                                portDiagnostics = NetworkTools.runPortDiagnostics("127.0.0.1")
                                isCheckingPort = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A3326)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonGreen),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isCheckingPort) {
                            CircularProgressIndicator(color = NeonGreen, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("RUNNING PORT TEST...", color = NeonGreen, fontWeight = FontWeight.Bold)
                        } else {
                            Text("RUN PORT DIAGNOSTIC", color = NeonGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Port Diagnostic Results
        if (portDiagnostics.isNotEmpty()) {
            item {
                Text(text = "Port Diagnostic Results", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            items(portDiagnostics) { p ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkGlass),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = "Port ${p.port} (${p.serviceName})", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (p.isOpen) Color(0xFF1E382A) else Color(0xFF2E1C22))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (p.isOpen) "OPEN" else "CLOSED / SECURE",
                                color = if (p.isOpen) NeonGreen else Color(0xFFFF5577),
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusMetric(label: String, value: String, color: Color) {
    Column {
        Text(text = label, color = Color.Gray, fontSize = 11.sp)
        Text(text = value, color = color, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}
