package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val XoDarkColorScheme = darkColorScheme(
  primary = NeonGreen,
  onPrimary = PureBlack,
  primaryContainer = NeonGreenGlow,
  onPrimaryContainer = NeonGreen,
  secondary = CyberCyan,
  onSecondary = PureBlack,
  tertiary = CyberPink,
  background = PureBlack,
  onBackground = TextPrimary,
  surface = DarkSurface,
  onSurface = TextPrimary,
  surfaceVariant = DarkGlass,
  onSurfaceVariant = TextSecondary,
  outline = DarkGlassBorder
)

private val XoLightColorScheme = lightColorScheme(
  primary = Color(0xFF00A341),
  onPrimary = Color.White,
  primaryContainer = Color(0xFFE0FCEB),
  onPrimaryContainer = Color(0xFF003814),
  secondary = Color(0xFF00838F),
  background = Color(0xFFF6F8F7),
  onBackground = Color(0xFF101412),
  surface = Color(0xFFFFFFFF),
  onSurface = Color(0xFF101412),
  surfaceVariant = Color(0xFFE8EFEB),
  onSurfaceVariant = Color(0xFF404A44),
  outline = Color(0xFFC0CEC6)
)

@Composable
fun XoAiTheme(
  darkTheme: Boolean = true,
  content: @Composable () -> Unit
) {
  val colorScheme = if (darkTheme) XoDarkColorScheme else XoLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  content: @Composable () -> Unit
) {
  XoAiTheme(darkTheme = darkTheme, content = content)
}
