package com.example.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.XoPreferences
import com.example.services.SpeechManager
import com.example.services.XoForegroundService
import com.example.ui.theme.DarkGlass
import com.example.ui.theme.DarkGlassBorder
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.PureBlack
import com.example.util.ShizukuHelper
import com.example.util.SystemControlHelper
import com.example.util.XoAccessibilityService

@Composable
fun SettingsTab(
    prefs: XoPreferences,
    speechManager: SpeechManager,
    onResetOnboarding: () -> Unit
) {
    val context = LocalContext.current
    val isServiceRunning by XoForegroundService.isServiceRunning.collectAsState()

    var apiKey by remember { mutableStateOf(prefs.apiKey) }
    var isKeyVisible by remember { mutableStateOf(false) }
    var wakeWordEnabled by remember { mutableStateOf(prefs.wakeWordEnabled) }
    var wakePhrase by remember { mutableStateOf(prefs.wakePhrase) }
    var voicePitch by remember { mutableFloatStateOf(prefs.voicePitch) }
    var voiceSpeed by remember { mutableFloatStateOf(prefs.voiceSpeed) }
    var isDarkMode by remember { mutableStateOf(prefs.isDarkMode) }

    var hasMicPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        )
    }

    val micLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasMicPermission = isGranted
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(16.dp)
            .testTag("settings_tab_screen"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(text = "XO AI Settings & Preferences", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(text = "Configure API key, voice engine, system permissions, and wake word.", color = Color.Gray, fontSize = 12.sp)
        }

        // 24/7 Foreground Service Toggle Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGlass),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkGlassBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "24/7 Foreground Service", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            text = if (isServiceRunning) "Service Active • Persistent Low-Resource Background Service" else "Service Stopped",
                            color = if (isServiceRunning) NeonGreen else Color.Gray,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = isServiceRunning,
                        onCheckedChange = { start ->
                            if (start) {
                                XoForegroundService.startService(context)
                            } else {
                                XoForegroundService.stopService(context)
                            }
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = PureBlack, checkedTrackColor = NeonGreen)
                    )
                }
            }
        }

        // Gemini API Key Section
        item {
            Card(colors = CardDefaults.cardColors(containerColor = DarkGlass), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Key, contentDescription = null, tint = NeonGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Google Gemini API Key", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = {
                            apiKey = it
                            prefs.apiKey = it
                        },
                        label = { Text("API Key") },
                        singleLine = true,
                        visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            Button(
                                onClick = { isKeyVisible = !isKeyVisible },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                            ) {
                                Text(if (isKeyVisible) "HIDE" else "SHOW", color = NeonGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonGreen,
                            unfocusedBorderColor = DarkGlassBorder,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Wake Word Section
        item {
            Card(colors = CardDefaults.cardColors(containerColor = DarkGlass), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Mic, contentDescription = null, tint = NeonGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Wake Word Activation", color = Color.White, fontWeight = FontWeight.Bold)
                        }

                        Switch(
                            checked = wakeWordEnabled,
                            onCheckedChange = {
                                wakeWordEnabled = it
                                prefs.wakeWordEnabled = it
                            },
                            colors = SwitchDefaults.colors(checkedThumbColor = PureBlack, checkedTrackColor = NeonGreen)
                        )
                    }

                    if (wakeWordEnabled) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = wakePhrase,
                            onValueChange = {
                                wakePhrase = it
                                prefs.wakePhrase = it
                            },
                            label = { Text("Wake Phrase") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonGreen,
                                unfocusedBorderColor = DarkGlassBorder,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // Voice Engine Speech Config
        item {
            Card(colors = CardDefaults.cardColors(containerColor = DarkGlass), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null, tint = NeonGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Voice Synthesis Pitch & Speed", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(text = "Pitch: ${String.format("%.2f", voicePitch)}x", color = Color.White)
                    Slider(
                        value = voicePitch,
                        onValueChange = {
                            voicePitch = it
                            prefs.voicePitch = it
                        },
                        valueRange = 0.5f..1.5f,
                        colors = SliderDefaults.colors(thumbColor = NeonGreen, activeTrackColor = NeonGreen)
                    )

                    Text(text = "Speed: ${String.format("%.2f", voiceSpeed)}x", color = Color.White)
                    Slider(
                        value = voiceSpeed,
                        onValueChange = {
                            voiceSpeed = it
                            prefs.voiceSpeed = it
                        },
                        valueRange = 0.5f..1.5f,
                        colors = SliderDefaults.colors(thumbColor = NeonGreen, activeTrackColor = NeonGreen)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { speechManager.speak("XO AI Speech synthesis test response.", pitch = voicePitch, rate = voiceSpeed) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B382A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("TEST SPEECH ENGINE", color = NeonGreen, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Theme Toggle Section
        item {
            Card(colors = CardDefaults.cardColors(containerColor = DarkGlass), modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Palette, contentDescription = null, tint = NeonGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Dark Theme Mode", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Switch(
                        checked = isDarkMode,
                        onCheckedChange = {
                            isDarkMode = it
                            prefs.isDarkMode = it
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = PureBlack, checkedTrackColor = NeonGreen)
                    )
                }
            }
        }

        // System Permissions Dashboard Card
        item {
            Card(colors = CardDefaults.cardColors(containerColor = DarkGlass), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = NeonGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "System Permissions Status", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    PermissionItem("Microphone Access", hasMicPermission) { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                    PermissionItem("System Overlay", android.provider.Settings.canDrawOverlays(context)) { SystemControlHelper.requestOverlayPermission(context) }
                    PermissionItem("Accessibility Service", XoAccessibilityService.isServiceActive) { SystemControlHelper.openSettingsScreen(context, android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS) }
                    PermissionItem("Shizuku Status", false) {}
                }
            }
        }

        // Restart Onboarding Wizard
        item {
            Button(
                onClick = onResetOnboarding,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E1920)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFF5577)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("reset_onboarding_button")
            ) {
                Icon(imageVector = Icons.Default.RestartAlt, contentDescription = null, tint = Color(0xFFFF5577))
                Spacer(modifier = Modifier.width(8.dp))
                Text("RE-RUN 6-STEP SETUP WIZARD", color = Color(0xFFFF5577), fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PermissionItem(
    title: String,
    isActive: Boolean,
    onRequest: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, color = Color.White, fontSize = 13.sp)

        if (isActive) {
            Text(text = "ACTIVE", color = NeonGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        } else {
            Button(
                onClick = onRequest,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22332A)),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("GRANT", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
