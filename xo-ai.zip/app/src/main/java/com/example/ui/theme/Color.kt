package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NeonGreen = Color(0xFF00FF66)
val NeonGreenDark = Color(0xFF00CC52)
val NeonGreenGlow = Color(0x3300FF66)

val CyberCyan = Color(0xFF00E5FF)
val CyberPink = Color(0xFFFF0055)

val PureBlack = Color(0xFF000000)
val DarkSurface = Color(0xFF0D110F)
val DarkGlass = Color(0xFF161E1A)
val DarkGlassBorder = Color(0xFF283830)
val DarkCard = Color(0xFF1E2824)

val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF9EAEA6)
val TextMuted = Color(0xFF62736B)
