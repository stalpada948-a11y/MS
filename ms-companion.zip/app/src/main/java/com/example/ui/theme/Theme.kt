package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MsDarkColorScheme = darkColorScheme(
    primary = MsRosePrimary,
    onPrimary = Color.White,
    secondary = MsPurpleSecondary,
    onSecondary = Color.White,
    tertiary = MsCyanTertiary,
    onTertiary = Color.Black,
    background = MsDarkBackground,
    onBackground = MsOnSurface,
    surface = MsDarkSurface,
    onSurface = MsOnSurface,
    surfaceVariant = MsDarkCard,
    onSurfaceVariant = MsPinkGlow
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MsDarkColorScheme,
        typography = Typography,
        content = content
    )
}

