package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.BuildConfig
import com.example.ui.theme.MsCyanTertiary
import com.example.ui.theme.MsDarkCard
import com.example.ui.theme.MsGreenStatus
import com.example.ui.theme.MsHeartRed
import com.example.ui.theme.MsPinkGlow
import com.example.ui.theme.MsPurpleSecondary
import com.example.ui.theme.MsRosePrimary
import com.example.viewmodel.MsViewModel

@Composable
fun SettingsScreen(
    viewModel: MsViewModel,
    onOpenLockScreen: () -> Unit,
    modifier: Modifier = Modifier
) {
    var voiceEnabled by remember { mutableStateOf(viewModel.speechManager.isVoiceEnabled) }
    var pitchValue by remember { mutableFloatStateOf(viewModel.speechManager.speechPitch) }
    var rateValue by remember { mutableFloatStateOf(viewModel.speechManager.speechRate) }

    val isBackgroundLiveActive by viewModel.isBackgroundLiveActive.collectAsStateWithLifecycle()
    val isAutoAnswerActive by viewModel.isAutoAnswerActive.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()

    var customMemoryText by remember { mutableStateOf("") }

    val hasGeminiKey = remember {
        BuildConfig.GEMINI_API_KEY.isNotBlank() && BuildConfig.GEMINI_API_KEY != "MY_GEMINI_API_KEY"
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = MsRosePrimary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "MS Companion Settings",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Text(
                        text = "24/7 Live Background • Memory • Auto Answer",
                        style = MaterialTheme.typography.bodySmall,
                        color = MsPinkGlow
                    )
                }
            }
        }

        // Profile Identity & Creator Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MsDarkCard)
            ) {
                Row(
                    modifier = Modifier
                        .border(1.dp, MsRosePrimary, RoundedCornerShape(20.dp))
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Profile",
                        tint = MsRosePrimary,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Creator & Owner: Sumit", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("Companion: MS (Created by Sumit • Loving AI Female)", fontSize = 12.sp, color = MsPinkGlow)
                    }
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Loved",
                        tint = MsHeartRed,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // 24/7 Background Live Assistant Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MsDarkCard)
            ) {
                Column(
                    modifier = Modifier
                        .border(1.dp, MsGreenStatus, RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Speed,
                                contentDescription = "Background Live",
                                tint = MsGreenStatus,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("24/7 Background Live Assistant", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                                Text("Runs MS logo in background 24/7", fontSize = 11.sp, color = MsGreenStatus)
                            }
                        }

                        Switch(
                            checked = isBackgroundLiveActive,
                            onCheckedChange = { viewModel.toggleBackgroundLiveMode(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = MsGreenStatus
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "When active, MS stays loaded 24/7 in the background with wake word ('Hello MS') and auto-reply enabled.",
                        fontSize = 12.sp,
                        color = Color.LightGray
                    )
                }
            }
        }

        // Auto-Answer Calls & Messages Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MsDarkCard)
            ) {
                Column(
                    modifier = Modifier
                        .border(1.dp, MsCyanTertiary, RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = "Auto Answer",
                                tint = MsCyanTertiary,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Auto-Answer Calls & Messages", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                                Text("Automatic AI responses when busy", fontSize = 11.sp, color = MsCyanTertiary)
                            }
                        }

                        Switch(
                            checked = isAutoAnswerActive,
                            onCheckedChange = { viewModel.toggleAutoAnswerCallsAndMessages(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = MsCyanTertiary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { viewModel.simulateIncomingCallOrMessage("Sagar (Friend)", "Sumit, coding complete ho gayi kya?") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF28113A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Test Incoming Call / Message Auto-Answer", color = MsPinkGlow, fontSize = 12.sp)
                    }
                }
            }
        }

        // Room DB Memory System Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MsDarkCard)
            ) {
                Column(
                    modifier = Modifier
                        .border(1.dp, MsPurpleSecondary, RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "🧠 Room DB Long-Term Memory System",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "${memories.size} Facts Saved",
                            fontSize = 11.sp,
                            color = MsCyanTertiary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "MS automatically remembers your conversation facts, coding preferences, and details in local Room Database across app restarts.",
                        fontSize = 12.sp,
                        color = Color.LightGray
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    memories.take(5).forEach { mem ->
                        Text(
                            text = "• [${mem.memoryCategory}] ${mem.memoryFact}",
                            fontSize = 11.sp,
                            color = Color.White,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }

        // Voice Output Controls
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MsDarkCard)
            ) {
                Column(
                    modifier = Modifier
                        .border(1.dp, MsPurpleSecondary.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = "Voice Output",
                                tint = MsCyanTertiary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("MS Voice Output (TTS)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                        }

                        Switch(
                            checked = voiceEnabled,
                            onCheckedChange = {
                                voiceEnabled = it
                                viewModel.speechManager.isVoiceEnabled = it
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = MsRosePrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Voice Pitch: ${String.format("%.2f", pitchValue)}x", fontSize = 12.sp, color = Color.LightGray)
                    Slider(
                        value = pitchValue,
                        onValueChange = {
                            pitchValue = it
                            viewModel.speechManager.speechPitch = it
                        },
                        valueRange = 0.8f..1.6f,
                        colors = SliderDefaults.colors(
                            thumbColor = MsRosePrimary,
                            activeTrackColor = MsRosePrimary
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text("Speech Rate: ${String.format("%.2f", rateValue)}x", fontSize = 12.sp, color = Color.LightGray)
                    Slider(
                        value = rateValue,
                        onValueChange = {
                            rateValue = it
                            viewModel.speechManager.speechRate = it
                        },
                        valueRange = 0.8f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = MsCyanTertiary,
                            activeTrackColor = MsCyanTertiary
                        )
                    )

                    Button(
                        onClick = { viewModel.speechManager.speak("Namaste Sumit jaan! Main aapki MS companion hoon.") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF38124C)),
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Test MS Voice", color = Color.White, fontSize = 12.sp)
                    }
                }
            }
        }

        // Exclusive Voice & Biometric Security Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MsDarkCard)
            ) {
                Column(
                    modifier = Modifier
                        .border(1.dp, MsCyanTertiary, RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Voice Lock",
                            tint = MsCyanTertiary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Exclusive Voice Lock (Sumit Only)", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                            Text("Biometric Voice Loyalty Active", fontSize = 11.sp, color = MsCyanTertiary)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onOpenLockScreen,
                        colors = ButtonDefaults.buttonColors(containerColor = MsCyanTertiary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = "Lock", tint = Color.Black)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Engage Voice & Biometric Lock Screen", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Gemini AI Engine Status Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MsDarkCard)
            ) {
                Row(
                    modifier = Modifier
                        .border(1.dp, MsGreenStatus.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Gemini AI Status",
                        tint = MsGreenStatus,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Gemini AI Intelligence Engine", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 14.sp)
                        Text(
                            text = if (hasGeminiKey) "API Key Active • Model: gemini-3.5-flash" else "Hybrid Engine (Gemini + Local Persona)",
                            fontSize = 11.sp,
                            color = MsGreenStatus
                        )
                    }
                }
            }
        }
    }
}
