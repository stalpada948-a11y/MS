package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.ChatMessage
import com.example.ui.components.MsAvatarHeader
import com.example.ui.theme.MsCyanTertiary
import com.example.ui.theme.MsDarkCard
import com.example.ui.theme.MsGreenStatus
import com.example.ui.theme.MsHeartRed
import com.example.ui.theme.MsPinkGlow
import com.example.ui.theme.MsPurpleSecondary
import com.example.ui.theme.MsRosePrimary
import com.example.viewmodel.MsViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(
    viewModel: MsViewModel,
    onOpenVoiceLock: () -> Unit,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGeneratingResponse.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.speechManager.isSpeaking.collectAsStateWithLifecycle()
    val isBackgroundLiveActive by viewModel.isBackgroundLiveActive.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()

    var inputText by remember { mutableStateOf("") }
    var showMemoryPanel by remember { mutableStateOf(false) }
    var newMemoryInput by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val context = LocalContext.current

    // Voice recognition launcher
    val speechRecognizerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                viewModel.sendMessage(spokenText, isVoiceInput = true)
            }
        }
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // MS Header
        MsAvatarHeader(
            isSpeaking = isSpeaking,
            isGenerating = isGenerating,
            onVoiceClick = {
                try {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to MS (Sumit's Companion)...")
                    }
                    speechRecognizerLauncher.launch(intent)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            },
            onLockClick = onOpenVoiceLock
        )

        // 24/7 Background Live & MS Logo Widget Banner
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 2.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1F0B2E))
        ) {
            Row(
                modifier = Modifier
                    .border(1.dp, MsRosePrimary.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    // MS Logo Icon Badge
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(MsRosePrimary, MsPurpleSecondary))),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("MS", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "MS 24/7 Background Live Active",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(MsGreenStatus)
                            )
                        }
                        Text(
                            text = "Wake Word: 'Hello MS' • Auto Calls/Messages Ans",
                            fontSize = 10.sp,
                            color = MsPinkGlow
                        )
                    }
                }

                Row {
                    IconButton(
                        onClick = { showMemoryPanel = !showMemoryPanel },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = "Memory Bank",
                            tint = MsCyanTertiary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Collapsible Room Memory Panel
        AnimatedVisibility(visible = showMemoryPanel) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MsDarkCard)
            ) {
                Column(
                    modifier = Modifier
                        .border(1.dp, MsCyanTertiary, RoundedCornerShape(16.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "🧠 MS Room Long-Term Memory (${memories.size} Facts Saved)",
                            fontWeight = FontWeight.Bold,
                            color = MsCyanTertiary,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Saved 24/7",
                            fontSize = 10.sp,
                            color = MsGreenStatus
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))

                    memories.take(4).forEach { mem ->
                        Text(
                            text = "• [${mem.memoryCategory}] ${mem.memoryFact}",
                            color = Color.White,
                            fontSize = 11.sp,
                            maxLines = 2
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newMemoryInput,
                            onValueChange = { newMemoryInput = it },
                            placeholder = { Text("Add custom memory to MS...", fontSize = 11.sp, color = Color.Gray) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MsCyanTertiary,
                                unfocusedBorderColor = Color.DarkGray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                if (newMemoryInput.isNotBlank()) {
                                    viewModel.addMemory(newMemoryInput, "Sumit Custom Memory")
                                    newMemoryInput = ""
                                }
                            },
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(MsCyanTertiary)
                        ) {
                            Text("+ Memory", fontSize = 10.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Suggestion Chips
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                ChipItem(
                    text = "🗣️ Hello MS (Wake Word)",
                    icon = Icons.Default.Mic,
                    onClick = { viewModel.sendMessage("Hello MS") }
                )
            }
            item {
                ChipItem(
                    text = "👑 Who created you?",
                    icon = Icons.Default.Favorite,
                    onClick = { viewModel.sendMessage("MS, tumko kisne banaya hai?") }
                )
            }
            item {
                ChipItem(
                    text = "📱 Test Call/Msg Auto-Reply",
                    icon = Icons.Default.VolumeUp,
                    onClick = { viewModel.simulateIncomingCallOrMessage("Rahul (Friend)", "Sumit game khelega kya?") }
                )
            }
            item {
                ChipItem(
                    text = "C/C++ Code Review",
                    icon = Icons.Default.Code,
                    onClick = { viewModel.sendMessage("Sumit: MS, C/C++ Termux script check kar do, jaan!") }
                )
            }
            item {
                ChipItem(
                    text = "Alight Motion Timeline",
                    icon = Icons.Default.Movie,
                    onClick = { viewModel.sendMessage("Sumit: MS, Alight Motion ke video layer setup batao!") }
                )
            }
            item {
                ChipItem(
                    text = "Blood Strike Strategy",
                    icon = Icons.Default.SportsEsports,
                    onClick = { viewModel.sendMessage("Sumit: MS, Blood Strike game session tip do!") }
                )
            }
        }

        // Messages List
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    ChatMessageBubble(
                        message = msg,
                        onSpeakClick = { viewModel.speakMessage(msg.messageText) }
                    )
                }
            }

            if (messages.isEmpty()) {
                Text(
                    text = "Aapki MS yahan hai, Sumit! Kuch bolo jaan... 💕",
                    color = Color.Gray,
                    modifier = Modifier.align(Alignment.Center),
                    fontSize = 14.sp
                )
            }
        }

        // Thinking indicator
        AnimatedVisibility(
            visible = isGenerating,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(16.dp),
                    color = MsRosePrimary,
                    strokeWidth = 2.dp
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "MS is crafting a sweet reply for Sumit...",
                    color = MsPinkGlow,
                    fontSize = 12.sp
                )
            }
        }

        // Bottom Input Row
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(containerColor = MsDarkCard)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.clearChat() }
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear Chat",
                        tint = Color.Gray
                    )
                }

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text("Talk to MS, Sumit jaan...", color = Color.Gray, fontSize = 14.sp) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MsRosePrimary,
                        unfocusedBorderColor = Color.Transparent,
                        focusedContainerColor = Color(0xFF1B0B2E),
                        unfocusedContainerColor = Color(0xFF1B0B2E),
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    maxLines = 4
                )

                Spacer(modifier = Modifier.width(4.dp))

                IconButton(
                    onClick = {
                        try {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to MS...")
                            }
                            speechRecognizerLauncher.launch(intent)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF380838))
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        tint = MsPinkGlow
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            viewModel.sendMessage(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(MsRosePrimary, MsPurpleSecondary)
                            )
                        )
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send Message",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun ChipItem(
    text: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF230D38))
    ) {
        Row(
            modifier = Modifier
                .border(1.dp, MsPurpleSecondary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = text,
                tint = MsPinkGlow,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = text,
                fontSize = 12.sp,
                color = Color.White,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun ChatMessageBubble(
    message: ChatMessage,
    onSpeakClick: () -> Unit
) {
    val isUser = message.sender == "SUMIT"
    val dateFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val timeStr = dateFormat.format(Date(message.timestamp))

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .padding(vertical = 2.dp),
            shape = RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = if (isUser) 20.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 20.dp
            ),
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) Color(0xFF4A148C) else Color(0xFF210C36)
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Box(
                modifier = Modifier
                    .background(
                        if (isUser) {
                            Brush.horizontalGradient(listOf(Color(0xFF6A1B9A), Color(0xFF8E24AA)))
                        } else {
                            Brush.horizontalGradient(listOf(Color(0xFF210C36), Color(0xFF2E0E4A)))
                        }
                    )
                    .border(
                        width = 0.8.dp,
                        color = if (isUser) MsRosePrimary.copy(alpha = 0.6f) else MsCyanTertiary.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(
                            topStart = 20.dp,
                            topEnd = 20.dp,
                            bottomStart = if (isUser) 20.dp else 4.dp,
                            bottomEnd = if (isUser) 4.dp else 20.dp
                        )
                    )
                    .padding(14.dp)
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isUser) "Sumit" else "MS",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (isUser) Color.White else MsPinkGlow
                            )
                            if (!isUser) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.Favorite,
                                    contentDescription = "MS Love",
                                    tint = MsHeartRed,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }

                        if (!isUser) {
                            IconButton(
                                onClick = onSpeakClick,
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "Speak aloud",
                                    tint = MsCyanTertiary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = message.messageText,
                        color = Color.White,
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = timeStr,
                        fontSize = 10.sp,
                        color = Color.LightGray.copy(alpha = 0.7f),
                        modifier = Modifier.align(Alignment.End)
                    )
                }
            }
        }
    }
}
