package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.AutoReplySetting
import com.example.ui.theme.MsCyanTertiary
import com.example.ui.theme.MsDarkCard
import com.example.ui.theme.MsGreenStatus
import com.example.ui.theme.MsHeartRed
import com.example.ui.theme.MsPinkGlow
import com.example.ui.theme.MsRosePrimary
import com.example.viewmodel.MsViewModel

@Composable
fun SystemMonitorScreen(
    viewModel: MsViewModel,
    modifier: Modifier = Modifier
) {
    val systemStatus by viewModel.systemStatus.collectAsStateWithLifecycle()
    val autoReplies by viewModel.autoReplies.collectAsStateWithLifecycle()

    var showAddAutoReply by remember { mutableStateOf(false) }
    var contactInput by remember { mutableStateOf("") }
    var replyTextInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Screen Title
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.DeveloperBoard,
                    contentDescription = "System Status",
                    tint = MsCyanTertiary,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "System & Background Monitor",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    )
                    Text(
                        text = "Real-time stats monitored by MS for Sumit 🔒",
                        style = MaterialTheme.typography.bodySmall,
                        color = MsPinkGlow
                    )
                }

                IconButton(onClick = { viewModel.updateSystemMetrics() }) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh Status",
                        tint = MsCyanTertiary
                    )
                }
            }
        }

        // Metrics Grid Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "Battery",
                    value = "${systemStatus.batteryPercent}%",
                    subtitle = if (systemStatus.isCharging) "Charging⚡" else "Healthy",
                    icon = if (systemStatus.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                    accentColor = MsGreenStatus,
                    modifier = Modifier.weight(1f)
                )

                MetricCard(
                    title = "Storage",
                    value = "${systemStatus.availableStorageGb} GB",
                    subtitle = "Free space",
                    icon = Icons.Default.SdStorage,
                    accentColor = MsCyanTertiary,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricCard(
                    title = "RAM Free",
                    value = "${systemStatus.ramFreeMb} MB",
                    subtitle = "Optimum for Gaming",
                    icon = Icons.Default.Memory,
                    accentColor = MsRosePrimary,
                    modifier = Modifier.weight(1f)
                )

                MetricCard(
                    title = "Voice Lock",
                    value = "SUMIT ONLY",
                    subtitle = "Biometric Active",
                    icon = Icons.Default.Security,
                    accentColor = MsPinkGlow,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Proactive Caring Tip
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF280B3A))
            ) {
                Box(
                    modifier = Modifier
                        .border(1.dp, MsRosePrimary, RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = "Proactive MS Tip",
                                tint = MsHeartRed,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "MS Proactive Care Advice",
                                fontWeight = FontWeight.Bold,
                                color = MsPinkGlow,
                                fontSize = 14.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Sumit jaan, device temperature standard hai aur storage space video rendering ke liye perfect hai! Agar aap Blood Strike ya Termux mein busy ho, toh auto-reply active hai! 💕",
                            fontSize = 13.sp,
                            color = Color.White,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }

        // Auto-Reply & Background Messaging Section
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Message,
                    contentDescription = "Auto Reply",
                    tint = MsRosePrimary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "WhatsApp & Gaming Auto-Reply Simulator",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )

                IconButton(onClick = { showAddAutoReply = !showAddAutoReply }) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Auto Reply",
                        tint = MsCyanTertiary
                    )
                }
            }
        }

        if (showAddAutoReply) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1E072E))
                ) {
                    Column(
                        modifier = Modifier
                            .border(1.dp, MsCyanTertiary, RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        Text("Add Auto-Reply Rule", fontWeight = FontWeight.Bold, color = MsCyanTertiary, fontSize = 14.sp)

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = contactInput,
                            onValueChange = { contactInput = it },
                            label = { Text("Contact / Group Name", color = Color.Gray) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MsCyanTertiary,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = replyTextInput,
                            onValueChange = { replyTextInput = it },
                            label = { Text("Auto-Reply Text", color = Color.Gray) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MsCyanTertiary,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Button(
                                onClick = { showAddAutoReply = false },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                            ) {
                                Text("Cancel", color = Color.Gray)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (contactInput.isNotBlank() && replyTextInput.isNotBlank()) {
                                        viewModel.addAutoReply(contactInput, replyTextInput)
                                        contactInput = ""
                                        replyTextInput = ""
                                        showAddAutoReply = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MsRosePrimary)
                            ) {
                                Text("Add Rule", color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        items(autoReplies, key = { it.id }) { rule ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MsDarkCard)
            ) {
                Row(
                    modifier = Modifier
                        .border(0.8.dp, MsRosePrimary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = rule.contactName,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "\"${rule.autoReplyText}\"",
                            fontSize = 12.sp,
                            color = MsPinkGlow
                        )
                    }

                    Switch(
                        checked = rule.isEnabled,
                        onCheckedChange = { viewModel.toggleAutoReply(rule) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = MsRosePrimary,
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = Color.DarkGray
                        )
                    )

                    IconButton(onClick = { viewModel.deleteAutoReply(rule) }) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete Rule",
                            tint = Color.Gray
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MsDarkCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    color = Color.LightGray,
                    fontWeight = FontWeight.Medium
                )

                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = accentColor
            )
        }
    }
}
