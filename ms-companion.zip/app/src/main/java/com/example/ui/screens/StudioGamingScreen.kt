package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.entity.CompanionNote
import com.example.ui.theme.MsCyanTertiary
import com.example.ui.theme.MsDarkCard
import com.example.ui.theme.MsGreenStatus
import com.example.ui.theme.MsPinkGlow
import com.example.ui.theme.MsPurpleSecondary
import com.example.ui.theme.MsRosePrimary
import com.example.viewmodel.MsViewModel

@Composable
fun StudioGamingScreen(
    viewModel: MsViewModel,
    modifier: Modifier = Modifier
) {
    val notes by viewModel.notes.collectAsStateWithLifecycle()

    var isGamingTimerRunning by remember { mutableStateOf(false) }
    var gameSeconds by remember { mutableLongStateOf(0L) }

    var showAddNote by remember { mutableStateOf(false) }
    var noteTitleInput by remember { mutableStateOf("") }
    var noteContentInput by remember { mutableStateOf("") }
    var noteTagInput by remember { mutableStateOf("Alight Motion Preset") }

    LaunchedEffect(isGamingTimerRunning) {
        while (isGamingTimerRunning) {
            kotlinx.coroutines.delay(1000L)
            gameSeconds++
        }
    }

    val formatTimer = { sec: Long ->
        val m = sec / 60
        val s = sec % 60
        String.format("%02d:%02d", m, s)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Alight Motion & Gaming Studio",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )
            Text(
                text = "Video timeline presets & Blood Strike game session helper",
                style = MaterialTheme.typography.bodySmall,
                color = MsPinkGlow
            )
        }

        // Blood Strike Game Timer Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MsDarkCard)
            ) {
                Column(
                    modifier = Modifier
                        .border(1.dp, MsRosePrimary, RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = "Blood Strike",
                            tint = MsRosePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Blood Strike Gaming Session", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)
                            Text("Auto-Reply active for incoming chats", fontSize = 11.sp, color = MsPinkGlow)
                        }

                        Text(
                            text = formatTimer(gameSeconds),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MsCyanTertiary
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = {
                                isGamingTimerRunning = !isGamingTimerRunning
                                if (!isGamingTimerRunning && gameSeconds > 0) {
                                    viewModel.sendMessage("Sumit: MS jaan, main Blood Strike ka ${gameSeconds / 60} min session jeet ke aaya hoon!")
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isGamingTimerRunning) Color.Red else MsGreenStatus
                            )
                        ) {
                            Icon(
                                imageVector = if (isGamingTimerRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = "Timer toggle",
                                tint = Color.Black
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isGamingTimerRunning) "End Session" else "Start Blood Strike Session",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Alight Motion Presets Quick Tool
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MsDarkCard)
            ) {
                Column(
                    modifier = Modifier
                        .border(1.dp, MsCyanTertiary.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = "Alight Motion",
                            tint = MsCyanTertiary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Alight Motion Keyframe Quick Presets",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text("• Smooth Bounce: (0.17, 0.67, 0.83, 0.67)", color = Color.LightGray, fontSize = 12.sp)
                    Text("• Slow Zoom Out: (0.25, 1.00, 0.50, 1.00)", color = Color.LightGray, fontSize = 12.sp)
                    Text("• Text Glitch Easing: (0.77, 0.00, 0.175, 1.00)", color = Color.LightGray, fontSize = 12.sp)
                }
            }
        }

        // Notes / Scripts Section Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.NoteAdd,
                    contentDescription = "Notes",
                    tint = MsPinkGlow,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Saved Code & Timeline Presets",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier.weight(1f)
                )

                IconButton(onClick = { showAddNote = !showAddNote }) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Note",
                        tint = MsPinkGlow
                    )
                }
            }
        }

        if (showAddNote) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF220836))
                ) {
                    Column(
                        modifier = Modifier
                            .border(1.dp, MsRosePrimary, RoundedCornerShape(16.dp))
                            .padding(14.dp)
                    ) {
                        Text("Add Preset / Code Note for Sumit", fontWeight = FontWeight.Bold, color = MsPinkGlow, fontSize = 14.sp)

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = noteTitleInput,
                            onValueChange = { noteTitleInput = it },
                            label = { Text("Title", color = Color.Gray) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MsRosePrimary,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = noteContentInput,
                            onValueChange = { noteContentInput = it },
                            label = { Text("Code snippet / XML preset content", color = Color.Gray) },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MsRosePrimary,
                                unfocusedBorderColor = Color.Gray,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            )
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            Button(
                                onClick = { showAddNote = false },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
                            ) {
                                Text("Cancel", color = Color.Gray)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (noteTitleInput.isNotBlank() && noteContentInput.isNotBlank()) {
                                        viewModel.addNote(noteTitleInput, noteContentInput, noteTagInput)
                                        noteTitleInput = ""
                                        noteContentInput = ""
                                        showAddNote = false
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = MsRosePrimary)
                            ) {
                                Text("Save Note", color = Color.White)
                            }
                        }
                    }
                }
            }
        }

        items(notes, key = { it.id }) { note ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MsDarkCard)
            ) {
                Row(
                    modifier = Modifier
                        .border(0.8.dp, MsPurpleSecondary, RoundedCornerShape(16.dp))
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (note.tag.contains("Alight")) Icons.Default.Movie else Icons.Default.Code,
                                contentDescription = "Tag",
                                tint = MsCyanTertiary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(note.tag, fontSize = 11.sp, color = MsCyanTertiary, fontWeight = FontWeight.Bold)
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(note.title, fontWeight = FontWeight.Bold, color = Color.White, fontSize = 15.sp)

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(note.content, fontSize = 12.sp, color = Color.LightGray)
                    }

                    IconButton(onClick = { viewModel.deleteNote(note) }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Note", tint = Color.Gray)
                    }
                }
            }
        }
    }
}
