package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MsRosePrimary = Color(0xFFF43F5E) // Elegant Rose 500
val MsRoseSoft = Color(0xFFFB7185) // Rose 400
val MsPinkGlow = Color(0xFFFDA4AF) // Soft Rose Glow
val MsPurpleSecondary = Color(0xFFA855F7) // Purple 500
val MsCyanTertiary = Color(0xFF38BDF8) // Sky Cyan 400

val MsDarkBackground = Color(0xFF0A0A0B) // Sleek Ultra-Dark Canvas (#0A0A0B)
val MsDarkSurface = Color(0xFF111114) // Elevated Dark Surface (#111114)
val MsDarkCard = Color(0xFF16161A) // Elegant Dark Card Container (#16161A)
val MsDarkBorder = Color(0xFF27272A) // Subtle Zinc Border

val MsOnSurface = Color(0xFFF1F5F9) // Slate 100
val MsTextMuted = Color(0xFF94A3B8) // Slate 400
val MsTextSubtle = Color(0xFF64748B) // Slate 500

val MsHeartRed = Color(0xFFF43F5E)
val MsGoldAccent = Color(0xFFFBBF24)
val MsGreenStatus = Color(0xFF34D399) // Emerald status

