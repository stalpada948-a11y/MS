package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Task
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.StudioGamingScreen
import com.example.ui.screens.SystemMonitorScreen
import com.example.ui.screens.TaskScreen
import com.example.ui.screens.VoiceLockScreen
import com.example.ui.theme.MsCyanTertiary
import com.example.ui.theme.MsDarkBackground
import com.example.ui.theme.MsPinkGlow
import com.example.ui.theme.MsRosePrimary
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MsViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScreen()
            }
        }
    }
}

enum class NavTab(val title: String, val icon: ImageVector) {
    CHAT("Chat", Icons.Default.ChatBubble),
    TASKS("Tasks", Icons.Default.Task),
    MONITOR("System", Icons.Default.DeveloperBoard),
    STUDIO("Studio", Icons.Default.Movie),
    SETTINGS("Settings", Icons.Default.Settings)
}

@Composable
fun MainAppScreen() {
    val msViewModel: MsViewModel = viewModel()
    var selectedTab by remember { mutableIntStateOf(0) }
    var showLockOverlay by remember { mutableStateOf(false) }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MsDarkBackground,
        bottomBar = {
            NavigationBar(
                containerColor = Color(0xFF1B0A2E),
                tonalElevation = 8.dp
            ) {
                NavTab.entries.forEachIndexed { index, tab ->
                    val isSelected = selectedTab == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { selectedTab = index },
                        icon = {
                            Icon(
                                imageVector = tab.icon,
                                contentDescription = tab.title,
                                tint = if (isSelected) MsRosePrimary else Color.Gray
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MsPinkGlow else Color.Gray
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = Color(0xFF380E4F)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                0 -> ChatScreen(
                    viewModel = msViewModel,
                    onOpenVoiceLock = { showLockOverlay = true }
                )
                1 -> TaskScreen(viewModel = msViewModel)
                2 -> SystemMonitorScreen(viewModel = msViewModel)
                3 -> StudioGamingScreen(viewModel = msViewModel)
                4 -> SettingsScreen(
                    viewModel = msViewModel,
                    onOpenLockScreen = { showLockOverlay = true }
                )
            }

            if (showLockOverlay) {
                VoiceLockScreen(
                    viewModel = msViewModel,
                    onDismiss = { showLockOverlay = false }
                )
            }
        }
    }
}
