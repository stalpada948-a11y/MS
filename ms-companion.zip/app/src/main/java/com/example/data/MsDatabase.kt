package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.AutoReplyDao
import com.example.data.dao.ChatMessageDao
import com.example.data.dao.CompanionNoteDao
import com.example.data.dao.UserMemoryDao
import com.example.data.dao.UserTaskDao
import com.example.data.entity.AutoReplySetting
import com.example.data.entity.ChatMessage
import com.example.data.entity.CompanionNote
import com.example.data.entity.UserMemory
import com.example.data.entity.UserTask

@Database(
    entities = [
        ChatMessage::class,
        UserTask::class,
        AutoReplySetting::class,
        CompanionNote::class,
        UserMemory::class
    ],
    version = 2,
    exportSchema = false
)
abstract class MsDatabase : RoomDatabase() {
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun userTaskDao(): UserTaskDao
    abstract fun autoReplyDao(): AutoReplyDao
    abstract fun companionNoteDao(): CompanionNoteDao
    abstract fun userMemoryDao(): UserMemoryDao

    companion object {
        @Volatile
        private var INSTANCE: MsDatabase? = null

        fun getDatabase(context: Context): MsDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MsDatabase::class.java,
                    "ms_companion_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
