package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "companion_notes")
data class CompanionNote(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val tag: String = "General", // "Termux Script", "Alight Motion Preset", "Blood Strike Sensitivity"
    val timestamp: Long = System.currentTimeMillis()
)
