package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_memories")
data class UserMemory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val memoryCategory: String = "Preference", // "Preference", "Fact", "Profile"
    val memoryFact: String,
    val timestamp: Long = System.currentTimeMillis()
)
