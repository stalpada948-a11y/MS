package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String, // "SUMIT" or "MS"
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isVoice: Boolean = false,
    val emotionTag: String = "caring" // "caring", "loving", "playful", "technical"
)
