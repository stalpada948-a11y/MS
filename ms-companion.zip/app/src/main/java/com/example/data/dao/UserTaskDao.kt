package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.UserTask
import kotlinx.coroutines.flow.Flow

@Dao
interface UserTaskDao {
    @Query("SELECT * FROM user_tasks ORDER BY isCompleted ASC, createdAt DESC")
    fun getAllTasks(): Flow<List<UserTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: UserTask): Long

    @Update
    suspend fun updateTask(task: UserTask)

    @Delete
    suspend fun deleteTask(task: UserTask)
}
