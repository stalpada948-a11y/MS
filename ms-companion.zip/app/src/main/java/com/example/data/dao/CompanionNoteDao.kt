package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.CompanionNote
import kotlinx.coroutines.flow.Flow

@Dao
interface CompanionNoteDao {
    @Query("SELECT * FROM companion_notes ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<CompanionNote>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: CompanionNote): Long

    @Update
    suspend fun updateNote(note: CompanionNote)

    @Delete
    suspend fun deleteNote(note: CompanionNote)
}
