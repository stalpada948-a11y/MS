package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_tasks")
data class UserTask(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String, // "Coding", "Video Editing", "Gaming", "General"
    val details: String = "",
    val isCompleted: Boolean = false,
    val priority: String = "Normal", // "High", "Normal", "Low"
    val createdAt: Long = System.currentTimeMillis()
)
