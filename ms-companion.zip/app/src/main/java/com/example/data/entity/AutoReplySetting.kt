package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "auto_reply_settings")
data class AutoReplySetting(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val contactName: String,
    val autoReplyText: String,
    val isEnabled: Boolean = true,
    val lastRepliedTime: Long = System.currentTimeMillis(),
    val replyCount: Int = 0
)
