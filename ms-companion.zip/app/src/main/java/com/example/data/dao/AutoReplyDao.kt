package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.AutoReplySetting
import kotlinx.coroutines.flow.Flow

@Dao
interface AutoReplyDao {
    @Query("SELECT * FROM auto_reply_settings ORDER BY lastRepliedTime DESC")
    fun getAllAutoReplies(): Flow<List<AutoReplySetting>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAutoReply(autoReply: AutoReplySetting): Long

    @Update
    suspend fun updateAutoReply(autoReply: AutoReplySetting)

    @Delete
    suspend fun deleteAutoReply(autoReply: AutoReplySetting)
}
