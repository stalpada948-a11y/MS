package com.example.data

import com.example.data.dao.AutoReplyDao
import com.example.data.dao.ChatMessageDao
import com.example.data.dao.CompanionNoteDao
import com.example.data.dao.UserMemoryDao
import com.example.data.dao.UserTaskDao
import com.example.data.entity.AutoReplySetting
import com.example.data.entity.ChatMessage
import com.example.data.entity.CompanionNote
import com.example.data.entity.UserMemory
import com.example.data.entity.UserTask
import kotlinx.coroutines.flow.Flow

class MsRepository(
    private val chatMessageDao: ChatMessageDao,
    private val userTaskDao: UserTaskDao,
    private val autoReplyDao: AutoReplyDao,
    private val companionNoteDao: CompanionNoteDao,
    private val userMemoryDao: UserMemoryDao
) {
    val allMessages: Flow<List<ChatMessage>> = chatMessageDao.getAllMessages()
    val allTasks: Flow<List<UserTask>> = userTaskDao.getAllTasks()
    val allAutoReplies: Flow<List<AutoReplySetting>> = autoReplyDao.getAllAutoReplies()
    val allNotes: Flow<List<CompanionNote>> = companionNoteDao.getAllNotes()
    val allMemories: Flow<List<UserMemory>> = userMemoryDao.getAllMemories()

    suspend fun insertMessage(message: ChatMessage): Long {
        return chatMessageDao.insertMessage(message)
    }

    suspend fun clearHistory() {
        chatMessageDao.clearHistory()
    }

    suspend fun insertTask(task: UserTask): Long {
        return userTaskDao.insertTask(task)
    }

    suspend fun updateTask(task: UserTask) {
        userTaskDao.updateTask(task)
    }

    suspend fun deleteTask(task: UserTask) {
        userTaskDao.deleteTask(task)
    }

    suspend fun insertAutoReply(autoReply: AutoReplySetting): Long {
        return autoReplyDao.insertAutoReply(autoReply)
    }

    suspend fun updateAutoReply(autoReply: AutoReplySetting) {
        autoReplyDao.updateAutoReply(autoReply)
    }

    suspend fun deleteAutoReply(autoReply: AutoReplySetting) {
        autoReplyDao.deleteAutoReply(autoReply)
    }

    suspend fun insertNote(note: CompanionNote): Long {
        return companionNoteDao.insertNote(note)
    }

    suspend fun updateNote(note: CompanionNote) {
        companionNoteDao.updateNote(note)
    }

    suspend fun deleteNote(note: CompanionNote) {
        companionNoteDao.deleteNote(note)
    }

    suspend fun insertMemory(memory: UserMemory): Long {
        return userMemoryDao.insertMemory(memory)
    }

    suspend fun deleteMemory(memory: UserMemory) {
        userMemoryDao.deleteMemory(memory)
    }

    suspend fun clearMemories() {
        userMemoryDao.clearMemories()
    }
}
