package com.example.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiClient
import com.example.ai.GeminiContent
import com.example.ai.GeminiPart
import com.example.ai.MsPersonaEngine
import com.example.ai.SpeechManager
import com.example.data.MsDatabase
import com.example.data.MsRepository
import com.example.data.entity.AutoReplySetting
import com.example.data.entity.ChatMessage
import com.example.data.entity.CompanionNote
import com.example.data.entity.UserMemory
import com.example.data.entity.UserTask
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class SystemStatus(
    val batteryPercent: Int = 85,
    val isCharging: Boolean = false,
    val availableStorageGb: Double = 32.5,
    val ramFreeMb: Int = 2048,
    val isVoiceLockEnabled: Boolean = true,
    val activeAutoReplyCount: Int = 2
)

class MsViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: MsRepository
    val speechManager: SpeechManager

    val messages: StateFlow<List<ChatMessage>>
    val tasks: StateFlow<List<UserTask>>
    val autoReplies: StateFlow<List<AutoReplySetting>>
    val notes: StateFlow<List<CompanionNote>>
    val memories: StateFlow<List<UserMemory>>

    private val _systemStatus = MutableStateFlow(SystemStatus())
    val systemStatus: StateFlow<SystemStatus> = _systemStatus.asStateFlow()

    private val _isGeneratingResponse = MutableStateFlow(false)
    val isGeneratingResponse: StateFlow<Boolean> = _isGeneratingResponse.asStateFlow()

    private val _isLocked = MutableStateFlow(false)
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private val _lockMessage = MutableStateFlow("")
    val lockMessage: StateFlow<String> = _lockMessage.asStateFlow()

    private val _isBackgroundLiveActive = MutableStateFlow(true)
    val isBackgroundLiveActive: StateFlow<Boolean> = _isBackgroundLiveActive.asStateFlow()

    private val _isAutoAnswerActive = MutableStateFlow(true)
    val isAutoAnswerActive: StateFlow<Boolean> = _isAutoAnswerActive.asStateFlow()

    init {
        val database = MsDatabase.getDatabase(application)
        repository = MsRepository(
            database.chatMessageDao(),
            database.userTaskDao(),
            database.autoReplyDao(),
            database.companionNoteDao(),
            database.userMemoryDao()
        )
        speechManager = SpeechManager(application)

        messages = repository.allMessages.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        tasks = repository.allTasks.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        autoReplies = repository.allAutoReplies.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        notes = repository.allNotes.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        memories = repository.allMemories.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        // Seed default initial data if database is empty
        viewModelScope.launch {
            repository.allMessages.collect { list ->
                if (list.isEmpty()) {
                    seedDefaultData()
                }
            }
        }

        updateSystemMetrics()
    }

    private suspend fun seedDefaultData() {
        val welcomeMsg = ChatMessage(
            sender = "MS",
            messageText = "Namaste Sumit jaan! ❤️ Main aapki MS companion 24/7 background live active hoon. Mujhe Sumit ne banaya hai aur mere paas ek long-term Room Memory system hai. Coding, video editing, calls auto-answer ya gaming sessions ke liye main ready hoon!",
            emotionTag = "loving"
        )
        repository.insertMessage(welcomeMsg)

        // Seed initial memories
        repository.insertMemory(
            UserMemory(
                memoryCategory = "Creator Profile",
                memoryFact = "Sumit created MS (AI Companion) to assist with coding, Alight Motion editing, and gaming 24/7."
            )
        )
        repository.insertMemory(
            UserMemory(
                memoryCategory = "User Preferences",
                memoryFact = "Sumit prefers Hinglish, terms of endearment ('jaan', 'sweetheart'), and active voice response."
            )
        )
        repository.insertMemory(
            UserMemory(
                memoryCategory = "Tech Stack",
                memoryFact = "Sumit works with C/C++, Python, Termux scripts, and Alight Motion timeline layers."
            )
        )

        // Default tasks
        repository.insertTask(
            UserTask(
                title = "Alight Motion Keyframe Preset Setup",
                category = "Video Editing",
                details = "Smooth velocity curves & text overlay effects for new edit",
                priority = "High"
            )
        )
        repository.insertTask(
            UserTask(
                title = "Termux C++ Compiler Setup",
                category = "Coding",
                details = "Install clang & gdb for Termux coding environment",
                priority = "Normal"
            )
        )
        repository.insertTask(
            UserTask(
                title = "Blood Strike Aim Sensitivity Test",
                category = "Gaming",
                details = "Gyroscope sensitivity tuning for 120fps gameplay",
                priority = "Normal"
            )
        )

        // Default auto-replies
        repository.insertAutoReply(
            AutoReplySetting(
                contactName = "WhatsApp Friends Group",
                autoReplyText = "Sumit is currently busy coding in Termux & playing Blood Strike. MS is managing his messages!",
                isEnabled = true
            )
        )

        // Default companion note
        repository.insertNote(
            CompanionNote(
                title = "Alight Motion Smooth Curve XML",
                content = "cubicspline(0.25, 0.1, 0.25, 1.0) - Best for text entry animations",
                tag = "Alight Motion Preset"
            )
        )
    }

    fun sendMessage(userText: String, isVoiceInput: Boolean = false) {
        if (userText.isBlank()) return

        viewModelScope.launch {
            val userMsg = ChatMessage(
                sender = "SUMIT",
                messageText = userText,
                isVoice = isVoiceInput,
                emotionTag = "loving"
            )
            repository.insertMessage(userMsg)

            _isGeneratingResponse.value = true

            // Automatically save memory if user mentions preferences or important facts
            autoExtractUserMemory(userText)

            // Convert history for Gemini with long term memory context
            val currentList = messages.value
            val history = currentList.takeLast(6).map {
                GeminiContent(
                    parts = listOf(GeminiPart(text = it.messageText)),
                    role = if (it.sender == "SUMIT") "user" else "model"
                )
            }

            // Append stored memories to system prompt
            val memoryContext = memories.value.joinToString("\n") { "- ${it.memoryCategory}: ${it.memoryFact}" }
            val systemPromptWithMemory = "${MsPersonaEngine.SYSTEM_PROMPT}\n\nStored Memories about Sumit (Room Database Persistence):\n$memoryContext"

            // Attempt Gemini API call first
            var aiReplyText = GeminiClient.generateMsReply(
                userText,
                history,
                systemPromptWithMemory
            )

            var emotionTag = "caring"

            // Fallback if empty or offline
            if (aiReplyText.isBlank()) {
                val fallbackPair = MsPersonaEngine.generateFallbackReply(userText)
                aiReplyText = fallbackPair.first
                emotionTag = fallbackPair.second
            }

            _isGeneratingResponse.value = false

            val msMsg = ChatMessage(
                sender = "MS",
                messageText = aiReplyText,
                isVoice = speechManager.isVoiceEnabled,
                emotionTag = emotionTag
            )
            repository.insertMessage(msMsg)

            if (speechManager.isVoiceEnabled) {
                speechManager.speak(aiReplyText)
            }
        }
    }

    private suspend fun autoExtractUserMemory(userText: String) {
        val lower = userText.lowercase()
        if (lower.contains("mujhe") || lower.contains("i like") || lower.contains("mera") || lower.contains("my favorite") || lower.contains("banaya")) {
            val memory = UserMemory(
                memoryCategory = "User Chat Fact",
                memoryFact = "Sumit said: '$userText'"
            )
            repository.insertMemory(memory)
        }
    }

    // Background Live Mode Control
    fun toggleBackgroundLiveMode(active: Boolean) {
        _isBackgroundLiveActive.value = active
    }

    // Auto Answer Calls & Messages Control
    fun toggleAutoAnswerCallsAndMessages(active: Boolean) {
        _isAutoAnswerActive.value = active
    }

    fun simulateIncomingCallOrMessage(senderName: String, incomingText: String) {
        viewModelScope.launch {
            val autoReplyMsg = "MS Auto-Reply (24/7 Live): Sumit is currently occupied. MS has taken your message: '$incomingText' and notified Sumit! ❤️"
            val chat = ChatMessage(
                sender = "MS (Auto-Responder)",
                messageText = "📱 Incoming message/call from $senderName: '$incomingText'\n🤖 $autoReplyMsg",
                emotionTag = "caring"
            )
            repository.insertMessage(chat)
            if (speechManager.isVoiceEnabled) {
                speechManager.speak("Sumit jaan! Incoming message from $senderName. MS handled auto reply!")
            }
        }
    }

    // Long-Term Memory System Operations
    fun addMemory(fact: String, category: String = "Custom Memory") {
        if (fact.isBlank()) return
        viewModelScope.launch {
            repository.insertMemory(
                UserMemory(
                    memoryCategory = category,
                    memoryFact = fact
                )
            )
        }
    }

    fun deleteMemory(memory: UserMemory) {
        viewModelScope.launch {
            repository.deleteMemory(memory)
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            repository.clearMemories()
        }
    }

    fun speakMessage(text: String) {
        speechManager.speak(text)
    }

    fun clearChat() {
        viewModelScope.launch {
            repository.clearHistory()
        }
    }

    // Task management
    fun addTask(title: String, category: String, details: String, priority: String) {
        viewModelScope.launch {
            repository.insertTask(
                UserTask(
                    title = title,
                    category = category,
                    details = details,
                    priority = priority
                )
            )
        }
    }

    fun toggleTaskCompleted(task: UserTask) {
        viewModelScope.launch {
            repository.updateTask(task.copy(isCompleted = !task.isCompleted))
        }
    }

    fun deleteTask(task: UserTask) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    // Auto reply management
    fun addAutoReply(contactName: String, replyText: String) {
        viewModelScope.launch {
            repository.insertAutoReply(
                AutoReplySetting(
                    contactName = contactName,
                    autoReplyText = replyText,
                    isEnabled = true
                )
            )
        }
    }

    fun toggleAutoReply(autoReply: AutoReplySetting) {
        viewModelScope.launch {
            repository.updateAutoReply(autoReply.copy(isEnabled = !autoReply.isEnabled))
        }
    }

    fun deleteAutoReply(autoReply: AutoReplySetting) {
        viewModelScope.launch {
            repository.deleteAutoReply(autoReply)
        }
    }

    // Note management
    fun addNote(title: String, content: String, tag: String) {
        viewModelScope.launch {
            repository.insertNote(
                CompanionNote(
                    title = title,
                    content = content,
                    tag = tag
                )
            )
        }
    }

    fun deleteNote(note: CompanionNote) {
        viewModelScope.launch {
            repository.deleteNote(note)
        }
    }

    // System metrics reader
    fun updateSystemMetrics() {
        try {
            val context = getApplication<Application>().applicationContext
            val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
                context.registerReceiver(null, filter)
            }
            val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL

            val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val batteryPct = if (level != -1 && scale != -1) (level * 100 / scale.toFloat()).toInt() else 88

            val stat = StatFs(Environment.getDataDirectory().path)
            val bytesAvailable = stat.availableBlocksLong * stat.blockSizeLong
            val gbsAvailable = (bytesAvailable / (1024.0 * 1024.0 * 1024.0))

            _systemStatus.value = SystemStatus(
                batteryPercent = batteryPct,
                isCharging = isCharging,
                availableStorageGb = String.format("%.1f", gbsAvailable).toDoubleOrNull() ?: 28.4,
                ramFreeMb = 2450,
                isVoiceLockEnabled = true,
                activeAutoReplyCount = autoReplies.value.count { it.isEnabled }
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun verifyVoiceBiometricAccess(voicePhrase: String): Boolean {
        return if (voicePhrase.lowercase().contains("sumit") || voicePhrase.lowercase().contains("ms")) {
            _isLocked.value = false
            _lockMessage.value = "Voice & Biometric Recognized: Welcome back Sumit jaan! 💖"
            true
        } else {
            _isLocked.value = true
            _lockMessage.value = "ACCESS DENIED! System is locked exclusively for Sumit! 🔒🚫"
            false
        }
    }

    fun toggleLockScreen(lock: Boolean) {
        _isLocked.value = lock
        if (lock) {
            _lockMessage.value = "Exclusive Biometric Voice Lock Engaged for Sumit!"
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechManager.shutdown()
    }
}
